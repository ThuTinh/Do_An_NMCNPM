﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAnNMCNPM_QuanLyThuVien.DTO
{
   public class QuyDinh3_DTO
    {
        private int soLuongSachToiDa;
        private int soNgayMuonToiDa;
        private DateTime hanThe;
        public QuyDinh3_DTO()
        {
            soLuongSachToiDa = 5;
            soNgayMuonToiDa = 4;
            HanThe = DateTime.Now;
        }
        public QuyDinh3_DTO(int _soLuongSachToiDa, int _soNgayMuonToiDa, DateTime _hanThe)
        {
            soLuongSachToiDa = _soLuongSachToiDa;
            soNgayMuonToiDa = _soNgayMuonToiDa;
            HanThe = _hanThe;
        }

        public int SoLuongSachToiDa { get => soLuongSachToiDa; set => soLuongSachToiDa = value; }
        public int SoNgayMuonToiDa { get => soNgayMuonToiDa; set => soNgayMuonToiDa = value; }
        public DateTime HanThe { get => hanThe; set => hanThe = value; }
    }
}
