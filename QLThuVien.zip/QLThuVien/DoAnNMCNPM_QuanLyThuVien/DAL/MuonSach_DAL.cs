﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using DoAnNMCNPM_QuanLyThuVien.DTO;
using System.Data;
using System.Windows.Forms;
using System.Data.Common;

namespace DoAnNMCNPM_QuanLyThuVien.DAL
{
    public class MuonSach_DAL
    {
        public MuonSach_DAL()
        {
            Connect();
        }


        SqlConnection con;
        void Connect()
        {
            con = new SqlConnection("Data Source=.;Initial Catalog=QLTV;Integrated Security=True");
        }


        public DataTable Select()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            DataTable table = new DataTable();
            string sqlQuery = "Select *from ctMuonSach";
            SqlDataAdapter aDapter = new SqlDataAdapter(sqlQuery, con);
            aDapter.Fill(table);
            con.Close();
            return table;
        }

        
        public bool Luu(MuonSach_DTO muonsach)
        {
            try
           {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string sqlQuery = @"INSERT INTO PhieuMuon(MaPhieuMuon,MaThuThu,MaThe,NgayMuon, NgayDuKienTra, SoLuong) VALUES (  '"+muonsach.MaPhieuMuon+"', '"+muonsach.MaThuThu+"', '"+muonsach.MaThe+"', '"+muonsach.NgayMuon+"','"+muonsach.NgayDuKienTra+"',"+muonsach.SoLuong+")";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();

                con.Close();
                return true; // muon thanh cong

            }
        catch(Exception e)
           {
              MessageBox.Show(e.ToString());
              return false; // muon that bai;
         }
        }

        public DataTable TimTen(MuonSach_DTO muonsach)
        {
            // Tạo connection
            if (con.State == ConnectionState.Closed)
                con.Open();
            DataTable table = new DataTable();

             string sqlQuery = @"select DOCGIA.TenDocGia from THEDOCGIA,DOCGIA where THEDOCGIA.MaDocGia=DOCGIA.MaDocGia and THEDOCGIA.MaThe='"+ muonsach.MaThe.ToString() + "'";
            //string sqlQuery = @"select DOCGIA.TenDocGia ,NgayMuon + 5 as ngaytra from THEDOCGIA, DOCGIA, PHIEUMUON where PHIEUMUON.MaThe = THEDOCGIA.MaThe AND THEDOCGIA.MaDocGia = DOCGIA.MaDocGia and THEDOCGIA.MaThe = '" + muonsach.MaThe.ToString() + "' AND MaPhieuMuon = '" + muonsach.MaPhieuMuon.ToString() + "'";
            SqlDataAdapter aDapter = new SqlDataAdapter(sqlQuery, con);
            aDapter.Fill(table);
            con.Close();
            return table;
        }

        // lấy ra giá trị hạn thẻ
        public DataTable HanThe(MuonSach_DTO muonsach)
        {



            // Tạo connection
            if (con.State == ConnectionState.Closed)
                con.Open();
            DataTable table = new DataTable();

            string sqlQuery = @"select HanThe from THEDOCGIA where MaThe='" + muonsach.MaThe+ "'";

            SqlDataAdapter aDapter = new SqlDataAdapter(sqlQuery, con);
            aDapter.Fill(table);
            //table.Columns["columnName"].ToString();
           // table.Table["DSTinh"].Rows[1].Item["columnName"].ToString();
            con.Close();
            return table;
        }


        public DataTable TimKiem(string TimKiemTheo, string tucantim)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                DataTable table = new DataTable();

                string sqlQuery = @"select * from ctmuonsach
                                where " + TimKiemTheo + " LIKE N'" + "%" + tucantim + "%" + "'";
                SqlDataAdapter aDapter = new SqlDataAdapter(sqlQuery, con);
                aDapter.Fill(table);
                con.Close();
                return table;
            }
            catch
            {
                DataTable table = new DataTable();
                return table;
            }
        }
        //public int SoLuongSachMuonTuTruoc;
        public DataTable  TraCuu(MuonSach_DTO muonsach)
        {
            
            

            if (con.State == ConnectionState.Closed)
                con.Open();
            DataTable table = new DataTable();
            string sqlQuery = @"select CUONSACH.MaSach,TenDauSach,TenTheLoai,DAUSACH.TacGia,CHITIETMUON.ChuThich from PHIEUMUON,CHITIETMUON, CUONSACH,DAUSACH where CHITIETMUON.MaPhieuMuon=PHIEUMUON.MaPhieuMuon and CUONSACH.MaSach=CHITIETMUON.MaSach and DAUSACH.MaDauSach=CUONSACH.MaDauSach and MaThe='" + muonsach.MaThe+"'";
            SqlDataAdapter aDapter = new SqlDataAdapter(sqlQuery, con);
            aDapter.Fill(table);
            //SoLuongSachMuonTuTruoc = table.Rows.Count-1;
            con.Close();
            return table;
        }
        public void update(string s,string y)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            
            string sqlQuery = @"update CUONSACH SET TinhTrang = '"+y+"' WHERE  MaSach= '"+s+"'";
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();
           // SqlCommand cmd = new SqlCommand(sqlQuery);
          //  cmd.Connection = con;
         //   cmd.ExecuteNonQuery();
            con.Close();
            //MessageBox.Show("Dal");
        }
    }
}

