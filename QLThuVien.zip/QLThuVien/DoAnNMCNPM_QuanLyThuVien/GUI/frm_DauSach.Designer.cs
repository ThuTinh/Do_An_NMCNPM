﻿namespace DoAnNMCNPM_QuanLyThuVien.GUI
{
    partial class frm_DauSach
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition1 = new Telerik.WinControls.UI.TableViewDefinition();
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition2 = new Telerik.WinControls.UI.TableViewDefinition();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.radGroupBox3 = new Telerik.WinControls.UI.RadGroupBox();
            this.txtMaDauSach = new Telerik.WinControls.UI.RadTextBoxControl();
            this.radLabel8 = new Telerik.WinControls.UI.RadLabel();
            this.cmbLoai = new Telerik.WinControls.UI.RadMultiColumnComboBox();
            this.radLabel9 = new Telerik.WinControls.UI.RadLabel();
            this.txtGia = new Telerik.WinControls.UI.RadTextBoxControl();
            this.txtSoLuongSach = new Telerik.WinControls.UI.RadTextBox();
            this.txtNXB = new Telerik.WinControls.UI.RadTextBoxControl();
            this.txtNamXB = new Telerik.WinControls.UI.RadTextBox();
            this.txtTacGia = new Telerik.WinControls.UI.RadTextBox();
            this.txtTenSach = new Telerik.WinControls.UI.RadTextBoxControl();
            this.radLabel7 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radGroupBox1 = new Telerik.WinControls.UI.RadGroupBox();
            this.btnCapNhap = new Telerik.WinControls.UI.RadButton();
            this.btnXoa = new Telerik.WinControls.UI.RadButton();
            this.btnThem = new Telerik.WinControls.UI.RadButton();
            this.btnLuu = new Telerik.WinControls.UI.RadButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radGroupBox2 = new Telerik.WinControls.UI.RadGroupBox();
            this.radGroupBox4 = new Telerik.WinControls.UI.RadGroupBox();
            this.btnTimKiem = new Telerik.WinControls.UI.RadButton();
            this.txtTuCanTim = new Telerik.WinControls.UI.RadTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbTimKiemTheo = new Telerik.WinControls.UI.RadMultiColumnComboBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).BeginInit();
            this.radGroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaDauSach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLoai)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLoai.EditorControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLoai.EditorControl.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoLuongSach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNXB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNamXB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTacGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTenSach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox1)).BeginInit();
            this.radGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnCapNhap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnXoa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnThem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLuu)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).BeginInit();
            this.radGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox4)).BeginInit();
            this.radGroupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnTimKiem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTuCanTim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo.EditorControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo.EditorControl.MasterTemplate)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column9,
            this.Column1,
            this.Column2,
            this.Column4,
            this.Column3,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column5});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1.Location = new System.Drawing.Point(2, 18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(538, 370);
            this.dataGridView1.TabIndex = 1;
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column9.HeaderText = "STT";
            this.Column9.Name = "Column9";
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "Mã đầu sách";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "Tên sách";
            this.Column2.Name = "Column2";
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.HeaderText = "Thể loại";
            this.Column4.Name = "Column4";
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "Tác giả";
            this.Column3.Name = "Column3";
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column6.HeaderText = "Giá";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column7.HeaderText = "Năm SX";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column8.HeaderText = "NXB";
            this.Column8.Name = "Column8";
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column5.HeaderText = "Số lượng";
            this.Column5.Name = "Column5";
            // 
            // radGroupBox3
            // 
            this.radGroupBox3.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.radGroupBox3.Controls.Add(this.txtMaDauSach);
            this.radGroupBox3.Controls.Add(this.radLabel8);
            this.radGroupBox3.Controls.Add(this.cmbLoai);
            this.radGroupBox3.Controls.Add(this.radLabel9);
            this.radGroupBox3.Controls.Add(this.txtGia);
            this.radGroupBox3.Controls.Add(this.txtSoLuongSach);
            this.radGroupBox3.Controls.Add(this.txtNXB);
            this.radGroupBox3.Controls.Add(this.txtNamXB);
            this.radGroupBox3.Controls.Add(this.txtTacGia);
            this.radGroupBox3.Controls.Add(this.txtTenSach);
            this.radGroupBox3.Controls.Add(this.radLabel7);
            this.radGroupBox3.Controls.Add(this.radLabel6);
            this.radGroupBox3.Controls.Add(this.radLabel5);
            this.radGroupBox3.Controls.Add(this.radLabel4);
            this.radGroupBox3.Controls.Add(this.radLabel3);
            this.radGroupBox3.Controls.Add(this.radLabel2);
            this.radGroupBox3.Dock = System.Windows.Forms.DockStyle.Left;
            this.radGroupBox3.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox3.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox3.HeaderText = "Thông tin";
            this.radGroupBox3.Location = new System.Drawing.Point(0, 0);
            this.radGroupBox3.Name = "radGroupBox3";
            this.radGroupBox3.Size = new System.Drawing.Size(403, 560);
            this.radGroupBox3.TabIndex = 12;
            this.radGroupBox3.Text = "Thông tin";
            // 
            // txtMaDauSach
            // 
            this.txtMaDauSach.Location = new System.Drawing.Point(126, 57);
            this.txtMaDauSach.Name = "txtMaDauSach";
            this.txtMaDauSach.Size = new System.Drawing.Size(202, 20);
            this.txtMaDauSach.TabIndex = 35;
            // 
            // radLabel8
            // 
            this.radLabel8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel8.Location = new System.Drawing.Point(23, 56);
            this.radLabel8.Name = "radLabel8";
            this.radLabel8.Size = new System.Drawing.Size(90, 19);
            this.radLabel8.TabIndex = 34;
            this.radLabel8.Text = "Mã đầu sách";
            // 
            // cmbLoai
            // 
            // 
            // cmbLoai.NestedRadGridView
            // 
            this.cmbLoai.EditorControl.BackColor = System.Drawing.SystemColors.Window;
            this.cmbLoai.EditorControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLoai.EditorControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cmbLoai.EditorControl.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.cmbLoai.EditorControl.MasterTemplate.AllowAddNewRow = false;
            this.cmbLoai.EditorControl.MasterTemplate.AllowCellContextMenu = false;
            this.cmbLoai.EditorControl.MasterTemplate.AllowColumnChooser = false;
            this.cmbLoai.EditorControl.MasterTemplate.EnableGrouping = false;
            this.cmbLoai.EditorControl.MasterTemplate.ShowFilteringRow = false;
            this.cmbLoai.EditorControl.MasterTemplate.ViewDefinition = tableViewDefinition1;
            this.cmbLoai.EditorControl.Name = "NestedRadGridView";
            this.cmbLoai.EditorControl.ReadOnly = true;
            this.cmbLoai.EditorControl.ShowGroupPanel = false;
            this.cmbLoai.EditorControl.Size = new System.Drawing.Size(240, 150);
            this.cmbLoai.EditorControl.TabIndex = 0;
            this.cmbLoai.Location = new System.Drawing.Point(126, 185);
            this.cmbLoai.Name = "cmbLoai";
            this.cmbLoai.Size = new System.Drawing.Size(202, 20);
            this.cmbLoai.TabIndex = 33;
            this.cmbLoai.TabStop = false;
            // 
            // radLabel9
            // 
            this.radLabel9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel9.Location = new System.Drawing.Point(23, 184);
            this.radLabel9.Name = "radLabel9";
            this.radLabel9.Size = new System.Drawing.Size(35, 19);
            this.radLabel9.TabIndex = 32;
            this.radLabel9.Text = "Loại";
            // 
            // txtGia
            // 
            this.txtGia.Location = new System.Drawing.Point(126, 319);
            this.txtGia.Name = "txtGia";
            this.txtGia.Size = new System.Drawing.Size(202, 20);
            this.txtGia.TabIndex = 31;
            // 
            // txtSoLuongSach
            // 
            this.txtSoLuongSach.Location = new System.Drawing.Point(126, 371);
            this.txtSoLuongSach.Name = "txtSoLuongSach";
            this.txtSoLuongSach.Size = new System.Drawing.Size(202, 20);
            this.txtSoLuongSach.TabIndex = 30;
            // 
            // txtNXB
            // 
            this.txtNXB.Location = new System.Drawing.Point(126, 272);
            this.txtNXB.Name = "txtNXB";
            this.txtNXB.Size = new System.Drawing.Size(202, 20);
            this.txtNXB.TabIndex = 29;
            // 
            // txtNamXB
            // 
            this.txtNamXB.Location = new System.Drawing.Point(126, 227);
            this.txtNamXB.Name = "txtNamXB";
            this.txtNamXB.Size = new System.Drawing.Size(202, 20);
            this.txtNamXB.TabIndex = 28;
            // 
            // txtTacGia
            // 
            this.txtTacGia.Location = new System.Drawing.Point(126, 139);
            this.txtTacGia.Name = "txtTacGia";
            this.txtTacGia.Size = new System.Drawing.Size(202, 20);
            this.txtTacGia.TabIndex = 27;
            // 
            // txtTenSach
            // 
            this.txtTenSach.Location = new System.Drawing.Point(126, 97);
            this.txtTenSach.Name = "txtTenSach";
            this.txtTenSach.Size = new System.Drawing.Size(202, 20);
            this.txtTenSach.TabIndex = 26;
            // 
            // radLabel7
            // 
            this.radLabel7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel7.Location = new System.Drawing.Point(23, 371);
            this.radLabel7.Name = "radLabel7";
            this.radLabel7.Size = new System.Drawing.Size(101, 19);
            this.radLabel7.TabIndex = 25;
            this.radLabel7.Text = "Số lượng sách";
            // 
            // radLabel6
            // 
            this.radLabel6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel6.Location = new System.Drawing.Point(23, 319);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(94, 19);
            this.radLabel6.TabIndex = 24;
            this.radLabel6.Text = "Giá/ 1 quyển";
            // 
            // radLabel5
            // 
            this.radLabel5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel5.Location = new System.Drawing.Point(23, 229);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(60, 19);
            this.radLabel5.TabIndex = 23;
            this.radLabel5.Text = "Năm XB";
            // 
            // radLabel4
            // 
            this.radLabel4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel4.Location = new System.Drawing.Point(23, 273);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(35, 19);
            this.radLabel4.TabIndex = 22;
            this.radLabel4.Text = "NXB";
            // 
            // radLabel3
            // 
            this.radLabel3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel3.Location = new System.Drawing.Point(23, 138);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(55, 19);
            this.radLabel3.TabIndex = 21;
            this.radLabel3.Text = "Tác giả";
            // 
            // radLabel2
            // 
            this.radLabel2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel2.Location = new System.Drawing.Point(23, 97);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(66, 19);
            this.radLabel2.TabIndex = 20;
            this.radLabel2.Text = "Tên sách";
            // 
            // radGroupBox1
            // 
            this.radGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.radGroupBox1.Controls.Add(this.btnCapNhap);
            this.radGroupBox1.Controls.Add(this.btnXoa);
            this.radGroupBox1.Controls.Add(this.btnThem);
            this.radGroupBox1.Controls.Add(this.btnLuu);
            this.radGroupBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.radGroupBox1.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox1.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox1.HeaderText = "Tác vụ";
            this.radGroupBox1.Location = new System.Drawing.Point(403, 0);
            this.radGroupBox1.Name = "radGroupBox1";
            this.radGroupBox1.Size = new System.Drawing.Size(179, 560);
            this.radGroupBox1.TabIndex = 13;
            this.radGroupBox1.Text = "Tác vụ";
            // 
            // btnCapNhap
            // 
            this.btnCapNhap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCapNhap.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnCapNhap.ForeColor = System.Drawing.Color.Black;
            this.btnCapNhap.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.Text_Edit_icon;
            this.btnCapNhap.Location = new System.Drawing.Point(26, 302);
            this.btnCapNhap.Name = "btnCapNhap";
            this.btnCapNhap.Size = new System.Drawing.Size(127, 53);
            this.btnCapNhap.TabIndex = 7;
            this.btnCapNhap.Text = "      CẬP NHẬP";
            // 
            // btnXoa
            // 
            this.btnXoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnXoa.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnXoa.ForeColor = System.Drawing.Color.Black;
            this.btnXoa.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.delete_file_icon;
            this.btnXoa.Location = new System.Drawing.Point(26, 204);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(127, 53);
            this.btnXoa.TabIndex = 6;
            this.btnXoa.Text = "    XÓA";
            // 
            // btnThem
            // 
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnThem.ForeColor = System.Drawing.Color.Black;
            this.btnThem.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.add_contact_icon;
            this.btnThem.Location = new System.Drawing.Point(26, 107);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(127, 53);
            this.btnThem.TabIndex = 5;
            this.btnThem.Text = "   THÊM";
            // 
            // btnLuu
            // 
            this.btnLuu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLuu.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnLuu.ForeColor = System.Drawing.Color.Black;
            this.btnLuu.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.Save_icon;
            this.btnLuu.Location = new System.Drawing.Point(26, 401);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(127, 53);
            this.btnLuu.TabIndex = 4;
            this.btnLuu.Text = "    LƯU";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radGroupBox2);
            this.panel1.Controls.Add(this.radGroupBox4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(582, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(542, 560);
            this.panel1.TabIndex = 15;
            // 
            // radGroupBox2
            // 
            this.radGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.radGroupBox2.Controls.Add(this.dataGridView1);
            this.radGroupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radGroupBox2.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox2.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox2.HeaderText = "Thông tin đầu sách";
            this.radGroupBox2.Location = new System.Drawing.Point(0, 170);
            this.radGroupBox2.Name = "radGroupBox2";
            this.radGroupBox2.Size = new System.Drawing.Size(542, 390);
            this.radGroupBox2.TabIndex = 16;
            this.radGroupBox2.Text = "Thông tin đầu sách";
            // 
            // radGroupBox4
            // 
            this.radGroupBox4.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.radGroupBox4.Controls.Add(this.btnTimKiem);
            this.radGroupBox4.Controls.Add(this.txtTuCanTim);
            this.radGroupBox4.Controls.Add(this.label2);
            this.radGroupBox4.Controls.Add(this.cmbTimKiemTheo);
            this.radGroupBox4.Controls.Add(this.label1);
            this.radGroupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.radGroupBox4.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox4.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox4.HeaderText = "Tìm kiếm nhanh";
            this.radGroupBox4.Location = new System.Drawing.Point(0, 0);
            this.radGroupBox4.Name = "radGroupBox4";
            this.radGroupBox4.Size = new System.Drawing.Size(542, 170);
            this.radGroupBox4.TabIndex = 15;
            this.radGroupBox4.Text = "Tìm kiếm nhanh";
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTimKiem.ForeColor = System.Drawing.Color.Black;
            this.btnTimKiem.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.Search_Images_icon;
            this.btnTimKiem.Location = new System.Drawing.Point(131, 97);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(116, 33);
            this.btnTimKiem.TabIndex = 11;
            this.btnTimKiem.Text = "      Tìm kiếm";
            // 
            // txtTuCanTim
            // 
            this.txtTuCanTim.Location = new System.Drawing.Point(433, 49);
            this.txtTuCanTim.Name = "txtTuCanTim";
            this.txtTuCanTim.Size = new System.Drawing.Size(127, 20);
            this.txtTuCanTim.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(338, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 9;
            this.label2.Text = "Từ cần tìm";
            // 
            // cmbTimKiemTheo
            // 
            // 
            // cmbTimKiemTheo.NestedRadGridView
            // 
            this.cmbTimKiemTheo.EditorControl.BackColor = System.Drawing.SystemColors.Window;
            this.cmbTimKiemTheo.EditorControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTimKiemTheo.EditorControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cmbTimKiemTheo.EditorControl.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.AllowAddNewRow = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.AllowCellContextMenu = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.AllowColumnChooser = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.EnableGrouping = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.ShowFilteringRow = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.ViewDefinition = tableViewDefinition2;
            this.cmbTimKiemTheo.EditorControl.Name = "NestedRadGridView";
            this.cmbTimKiemTheo.EditorControl.ReadOnly = true;
            this.cmbTimKiemTheo.EditorControl.ShowGroupPanel = false;
            this.cmbTimKiemTheo.EditorControl.Size = new System.Drawing.Size(240, 150);
            this.cmbTimKiemTheo.EditorControl.TabIndex = 0;
            this.cmbTimKiemTheo.Location = new System.Drawing.Point(131, 51);
            this.cmbTimKiemTheo.Name = "cmbTimKiemTheo";
            this.cmbTimKiemTheo.Size = new System.Drawing.Size(161, 20);
            this.cmbTimKiemTheo.TabIndex = 7;
            this.cmbTimKiemTheo.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(24, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Tìm kiếm theo";
            // 
            // frm_DauSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.radGroupBox1);
            this.Controls.Add(this.radGroupBox3);
            this.Name = "frm_DauSach";
            this.Size = new System.Drawing.Size(1124, 560);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).EndInit();
            this.radGroupBox3.ResumeLayout(false);
            this.radGroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaDauSach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLoai.EditorControl.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLoai.EditorControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLoai)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoLuongSach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNXB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNamXB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTacGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTenSach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox1)).EndInit();
            this.radGroupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnCapNhap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnXoa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnThem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLuu)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).EndInit();
            this.radGroupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox4)).EndInit();
            this.radGroupBox4.ResumeLayout(false);
            this.radGroupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnTimKiem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTuCanTim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo.EditorControl.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo.EditorControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox3;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private Telerik.WinControls.UI.RadTextBoxControl txtMaDauSach;
        private Telerik.WinControls.UI.RadLabel radLabel8;
        private Telerik.WinControls.UI.RadMultiColumnComboBox cmbLoai;
        private Telerik.WinControls.UI.RadLabel radLabel9;
        private Telerik.WinControls.UI.RadTextBoxControl txtGia;
        private Telerik.WinControls.UI.RadTextBox txtSoLuongSach;
        private Telerik.WinControls.UI.RadTextBoxControl txtNXB;
        private Telerik.WinControls.UI.RadTextBox txtNamXB;
        private Telerik.WinControls.UI.RadTextBox txtTacGia;
        private Telerik.WinControls.UI.RadTextBoxControl txtTenSach;
        private Telerik.WinControls.UI.RadLabel radLabel7;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private System.Windows.Forms.Panel panel1;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox2;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox4;
        private Telerik.WinControls.UI.RadTextBox txtTuCanTim;
        private System.Windows.Forms.Label label2;
        private Telerik.WinControls.UI.RadMultiColumnComboBox cmbTimKiemTheo;
        private System.Windows.Forms.Label label1;
        private Telerik.WinControls.UI.RadButton btnCapNhap;
        private Telerik.WinControls.UI.RadButton btnXoa;
        private Telerik.WinControls.UI.RadButton btnThem;
        private Telerik.WinControls.UI.RadButton btnLuu;
        private Telerik.WinControls.UI.RadButton btnTimKiem;
    }
}
