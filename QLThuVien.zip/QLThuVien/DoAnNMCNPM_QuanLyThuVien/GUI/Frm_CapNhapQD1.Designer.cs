﻿namespace DoAnNMCNPM_QuanLyThuVien
{
    partial class Frm_CapNhapQD1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radButton3 = new Telerik.WinControls.UI.RadButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTuoiDocGiaTu = new Telerik.WinControls.UI.RadTextBox();
            this.txtDen = new Telerik.WinControls.UI.RadTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtHanThe = new Telerik.WinControls.UI.RadTextBox();
            this.btnLuu = new Telerik.WinControls.UI.RadButton();
            ((System.ComponentModel.ISupportInitialize)(this.radButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTuoiDocGiaTu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHanThe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLuu)).BeginInit();
            this.SuspendLayout();
            // 
            // radButton3
            // 
            this.radButton3.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.logo;
            this.radButton3.Location = new System.Drawing.Point(332, 302);
            this.radButton3.Name = "radButton3";
            this.radButton3.Size = new System.Drawing.Size(71, 41);
            this.radButton3.TabIndex = 24;
            this.radButton3.Text = "Lưu";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tuổi độc giả từ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(173, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Đến";
            // 
            // txtTuoiDocGiaTu
            // 
            this.txtTuoiDocGiaTu.Location = new System.Drawing.Point(101, 30);
            this.txtTuoiDocGiaTu.Name = "txtTuoiDocGiaTu";
            this.txtTuoiDocGiaTu.Size = new System.Drawing.Size(63, 20);
            this.txtTuoiDocGiaTu.TabIndex = 25;
            // 
            // txtDen
            // 
            this.txtDen.Location = new System.Drawing.Point(206, 30);
            this.txtDen.Name = "txtDen";
            this.txtDen.Size = new System.Drawing.Size(63, 20);
            this.txtDen.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Hạng thẻ(Tháng)";
            // 
            // txtHanThe
            // 
            this.txtHanThe.Location = new System.Drawing.Point(101, 63);
            this.txtHanThe.Name = "txtHanThe";
            this.txtHanThe.Size = new System.Drawing.Size(63, 20);
            this.txtHanThe.TabIndex = 25;
            // 
            // btnLuu
            // 
            this.btnLuu.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.logo;
            this.btnLuu.Location = new System.Drawing.Point(206, 101);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(64, 32);
            this.btnLuu.TabIndex = 26;
            this.btnLuu.Text = "Lưu";
            // 
            // Frm_CapNhapQD1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(291, 151);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.txtHanThe);
            this.Controls.Add(this.txtTuoiDocGiaTu);
            this.Controls.Add(this.radButton3);
            this.Controls.Add(this.txtDen);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Name = "Frm_CapNhapQD1";
            this.Text = "Frm_CapNhapQD";
            ((System.ComponentModel.ISupportInitialize)(this.radButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTuoiDocGiaTu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHanThe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLuu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Telerik.WinControls.UI.RadButton radButton3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private Telerik.WinControls.UI.RadTextBox txtTuoiDocGiaTu;
        private Telerik.WinControls.UI.RadTextBox txtDen;
        private System.Windows.Forms.Label label4;
        private Telerik.WinControls.UI.RadTextBox txtHanThe;
        private Telerik.WinControls.UI.RadButton btnLuu;
    }
}