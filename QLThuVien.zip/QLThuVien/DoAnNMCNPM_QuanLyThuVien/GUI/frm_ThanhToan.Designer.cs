﻿namespace DoAnNMCNPM_QuanLyThuVien.GUI
{
    partial class frm_ThanhToan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.txtTongTienThu = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.lbTongNo = new Telerik.WinControls.UI.RadLabel();
            this.txtTienTraLai = new Telerik.WinControls.UI.RadLabel();
            this.lbMaPhieuTra = new Telerik.WinControls.UI.RadLabel();
            this.btnThanhToan = new Telerik.WinControls.UI.RadButton();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongTienThu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbTongNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTienTraLai)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbMaPhieuTra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnThanhToan)).BeginInit();
            this.SuspendLayout();
            // 
            // radLabel1
            // 
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radLabel1.Location = new System.Drawing.Point(25, 22);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(81, 19);
            this.radLabel1.TabIndex = 1;
            this.radLabel1.Text = "Mã phiếu trả";
            // 
            // radLabel2
            // 
            this.radLabel2.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radLabel2.Location = new System.Drawing.Point(25, 64);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(54, 19);
            this.radLabel2.TabIndex = 1;
            this.radLabel2.Text = "Tổng nợ";
            // 
            // radLabel3
            // 
            this.radLabel3.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radLabel3.Location = new System.Drawing.Point(25, 109);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(84, 19);
            this.radLabel3.TabIndex = 2;
            this.radLabel3.Text = "Tổng tiền thu";
            // 
            // txtTongTienThu
            // 
            this.txtTongTienThu.Location = new System.Drawing.Point(120, 109);
            this.txtTongTienThu.Name = "txtTongTienThu";
            this.txtTongTienThu.Size = new System.Drawing.Size(110, 20);
            this.txtTongTienThu.TabIndex = 0;
            // 
            // radLabel4
            // 
            this.radLabel4.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radLabel4.Location = new System.Drawing.Point(25, 155);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(70, 19);
            this.radLabel4.TabIndex = 2;
            this.radLabel4.Text = "Tiền trả lại";
            // 
            // lbTongNo
            // 
            this.lbTongNo.AutoSize = false;
            this.lbTongNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbTongNo.Location = new System.Drawing.Point(120, 63);
            this.lbTongNo.Name = "lbTongNo";
            this.lbTongNo.Size = new System.Drawing.Size(110, 18);
            this.lbTongNo.TabIndex = 3;
            // 
            // txtTienTraLai
            // 
            this.txtTienTraLai.AutoSize = false;
            this.txtTienTraLai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtTienTraLai.Location = new System.Drawing.Point(120, 155);
            this.txtTienTraLai.Name = "txtTienTraLai";
            this.txtTienTraLai.Size = new System.Drawing.Size(110, 18);
            this.txtTienTraLai.TabIndex = 3;
            // 
            // lbMaPhieuTra
            // 
            this.lbMaPhieuTra.AutoSize = false;
            this.lbMaPhieuTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbMaPhieuTra.Location = new System.Drawing.Point(120, 23);
            this.lbMaPhieuTra.Name = "lbMaPhieuTra";
            this.lbMaPhieuTra.Size = new System.Drawing.Size(110, 18);
            this.lbMaPhieuTra.TabIndex = 3;
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.ForeColor = System.Drawing.Color.Black;
            this.btnThanhToan.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.cart_icon__1_;
            this.btnThanhToan.Location = new System.Drawing.Point(120, 196);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(110, 39);
            this.btnThanhToan.TabIndex = 4;
            this.btnThanhToan.Text = "Thanh toán";
            // 
            // frm_ThanhToan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(285, 247);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.txtTienTraLai);
            this.Controls.Add(this.lbMaPhieuTra);
            this.Controls.Add(this.lbTongNo);
            this.Controls.Add(this.radLabel4);
            this.Controls.Add(this.radLabel3);
            this.Controls.Add(this.radLabel2);
            this.Controls.Add(this.radLabel1);
            this.Controls.Add(this.txtTongTienThu);
            this.Name = "frm_ThanhToan";
            this.Text = "frm_ThanhToan";
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongTienThu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbTongNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTienTraLai)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbMaPhieuTra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnThanhToan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadTextBox txtTongTienThu;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadLabel lbTongNo;
        private Telerik.WinControls.UI.RadLabel txtTienTraLai;
        private Telerik.WinControls.UI.RadButton btnThanhToan;
        private Telerik.WinControls.UI.RadLabel lbMaPhieuTra;
    }
}