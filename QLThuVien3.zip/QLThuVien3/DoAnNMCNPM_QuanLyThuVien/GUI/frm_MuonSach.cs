﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DoAnNMCNPM_QuanLyThuVien.DTO;
using DoAnNMCNPM_QuanLyThuVien.DAL;
using System.Data.SqlClient;
using DoAnNMCNPM_QuanLyThuVien.BUS;

namespace DoAnNMCNPM_QuanLyThuVien.GUI
{
    public partial class frm_MuonSach : UserControl
    {
        public frm_MuonSach()
        {
            InitializeComponent();
            muonsachBUS = new MuonSach_BUS();
            muonsachDTO = new MuonSach_DTO();
            CTmuonsachBUS = new ChiTietMuonSach_BUS();
            CTmuonsachDTO = new ChiTietMuonSach_DTO();

            KhoiTaoCmbTiemKiem();
        }

        MuonSach_DTO muonsachDTO;
        MuonSach_BUS muonsachBUS;

        ChiTietMuonSach_BUS CTmuonsachBUS;
        ChiTietMuonSach_DTO CTmuonsachDTO;
        QuyDinh3_BUS quydinh3BUS;
        QuyDinh3_DTO quydinh3DTO;


        void Lock()
        {
            txtHoTen.Enabled = false;
            txtMaPhieuMuon.Enabled = false;
            txtMaThe.Enabled = false;
            txtMaThuThu.Enabled = false;
            dtNgayMuon.Enabled = false;
            dtNgayDuKienTra.Enabled = false;
            dgvDanhSachSach.Enabled = false;
        }


        void UnLock()
        {

            txtHoTen.Enabled = true;
            txtMaPhieuMuon.Enabled = true;
            txtMaThe.Enabled = true;
            txtMaThuThu.Enabled = true;
            dtNgayMuon.Enabled = true;
            dtNgayDuKienTra.Enabled = true;
            dgvDanhSachSach.Enabled = true;
        }


        void KhoiTaoCmbTiemKiem()
        {
            DataTable Loai = new DataTable();
            Loai.Columns.Add("Tìm kiếm theo");
            Loai.Rows.Add("MaSach");
            Loai.Rows.Add("TenSach");
            Loai.Rows.Add("TheLoai");
            Loai.Rows.Add("TacGia");
            Loai.Rows.Add("TinhTrang");
            cmbTimKiemTheo.DataSource = Loai;
        }


        void TimTen()
        {
            KhoiTaoDTO();
            txtHoTen.DataBindings.Clear();
            txtHoTen.DataBindings.Add("Text", (muonsachBUS.TimTenBUS(muonsachDTO)), "TenDocGia");
            muonsachDTO.HoTen = txtHoTen.Text;
        }
      
        bool KiemTraHanThe()
        {
            
            txtHoTen.DataBindings.Clear();
            txtHoTen.DataBindings.Add("Text", (muonsachBUS.HanThe(muonsachDTO)), "HanThe");
            DateTime s = DateTime.Parse(txtHoTen.Text.ToString());
            DateTime ss = DateTime.Parse(DateTime.Now.ToShortDateString());
            if (s < ss)
            {
                //MessageBox.Show("Thẻ Đã hết hạn");
                return false;
            }
           
            return true;
        }

        bool KiemTraSachQuaHanTra()
        {
            txtHoTen.DataBindings.Clear();
            txtHoTen.DataBindings.Add("Text", (muonsachBUS.demsachquahantra(muonsachDTO)), "SOLUONGSACHTRAMUON");
            if (int.Parse(txtHoTen.Text)<0)
            {
                MessageBox.Show("Thẻ có"+txtHoTen.ToString()+" sách chưa trả bị quá hạn");
                return false;
            }
        return true;
        }

        void KhoiTaoDTO()
        {
            
            muonsachDTO.MaPhieuMuon = txtMaPhieuMuon.Text;
            muonsachDTO.MaThuThu = txtMaThuThu.Text;
            muonsachDTO.MaThe = txtMaThe.Text;
            dtNgayMuon.Value = DateTime.Now;
            dtNgayDuKienTra.Value = dtNgayMuon.Value.AddDays(5);
            muonsachDTO.NgayDuKienTra = dtNgayDuKienTra.Value.Date.ToString("MM/dd/yyyy");
            muonsachDTO.NgayMuon = dtNgayMuon.Value.Date.ToString("MM/dd/yyyy");
            muonsachDTO.SoLuong = int.Parse((dgvDanhSachMuon.RowCount - 1).ToString());

        }

        void Forcus()
        {
            txtHoTen.Text = "";
            txtMaPhieuMuon.Text = "";
            txtMaThe.Text = "";
            txtMaThuThu.Text = "";
            dtNgayMuon.Text = "";
            dtNgayDuKienTra.Text = "";
           // lblSoLuongSachDaMuon.Text="-1";
        }

        private void btnMuon_Click(object sender, EventArgs e)
        {
            UnLock();

            Forcus();
        }
        private void btnLuu_Click_1(object sender, EventArgs e)
        {
            KhoiTaoDTO();
            if (KiemTraHanThe() == false)
            {
                MessageBox.Show("Thẻ Đã hết hạn");
                return;
            }
            if(KiemTraSachQuaHanTra()==false)
            {
                MessageBox.Show("Bạn không thể mượn vì sách chưa trả bị quá hạn ");
                return;
            }
            TimTen();
            dtNgayDuKienTra.Value = dtNgayMuon.Value.AddDays(5);
            muonsachBUS.Muon(muonsachDTO);
            foreach (DataGridViewRow row in dgvDanhSachMuon.SelectedRows)
            {
                string s = dgvDanhSachMuon[0, row.Index].Value.ToString();
                string n = "Y";
                muonsachBUS.update(s, n);
                dgvDanhSachSach.DataSource = muonsachBUS.Select();
            }
            muonsachBUS.Luu(muonsachDTO);
            LuuChiTietMuonSach();
            lblSoLuongSachDaMuon.Text = "";
            Forcus();
        }

        int i = 0;
        int t = 0;
        void SoLuonSachMuonTuTruoc()
        {
            KhoiTaoDTO();
            lblSoLuongSachDaMuon.DataBindings.Clear();
            lblSoLuongSachDaMuon.DataBindings.Add("Text", (muonsachBUS.SoLuongSachMuonTuTruoc(txtMaThe.Text)), "SoLuongSachDaMuonTuTruoc");
        }
        private void dgvDanhSachSach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (txtMaPhieuMuon.Text==""||txtMaThe.Text==""||txtMaThuThu.Text=="")
            {
                MessageBox.Show("Bạn hãy nhập thông tin đầy đủ trước khi mượn!");
                return;
            }

            if (dgvDanhSachSach[4, dgvDanhSachSach.CurrentRow.Index].Value == "Y")
            {
                MessageBox.Show("Sách này không còn");
                return;

            }
            else
            {
                t += 1;
            }
            SoLuonSachMuonTuTruoc();
            string abc = lblSoLuongSachDaMuon.Text;
            i = int.Parse(abc.ToString());
            i += t;

            if (i >5)
            {
                MessageBox.Show("chỉ được mượn tối đa 5 quyển");
                return;
            }
            
                int row = dgvDanhSachMuon.Rows.Add();
                dgvDanhSachMuon[3, row].Value = dgvDanhSachSach[1, dgvDanhSachSach.CurrentRow.Index].Value;

                dgvDanhSachMuon[1, row].Value = dgvDanhSachSach[0, dgvDanhSachSach.CurrentRow.Index].Value;

                dgvDanhSachMuon[2, row].Value = dgvDanhSachSach[2, dgvDanhSachSach.CurrentRow.Index].Value;

                dgvDanhSachMuon[0, row].Value = dgvDanhSachSach[3, dgvDanhSachSach.CurrentRow.Index].Value;

                dgvDanhSachMuon[4, row].Value = dgvDanhSachSach[5, dgvDanhSachSach.CurrentRow.Index].Value;
                
                dgvDanhSachSach[4, dgvDanhSachSach.CurrentRow.Index].Value = "Y";

            string s = dgvDanhSachSach[3, dgvDanhSachSach.CurrentRow.Index].Value.ToString();
            muonsachBUS.update(s, "Y");

        }


        private void btnHuyMuon_Click(object sender, EventArgs e)
        {
            if (dgvDanhSachMuon.CurrentRow == null)
            {
                return;
            }
            int k = 1;
            foreach (DataGridViewRow row in dgvDanhSachMuon.SelectedRows)
            {
                int j = row.Index;
                string s = dgvDanhSachMuon.Rows[j].Cells[0].FormattedValue.ToString();
                muonsachBUS.update(s, "N");
                dgvDanhSachMuon.Rows.Remove(row);
                k += 1;
            }
            t -= k;
          
            dgvDanhSachSach.DataSource = muonsachBUS.Select();
        }
        private void btnTimKiem_Click_1(object sender, EventArgs e)
        {
            dgvDanhSachSach.DataSource = muonsachBUS.TimKiem(cmbTimKiemTheo.Text, txtTuCanTim.Text);

        }
        private void btnThoat_Click(object sender, EventArgs e)
        {

            dgvDanhSachSach.DataSource = muonsachBUS.Select();
        

        }
        private void frm_MuonSach_Load_1(object sender, EventArgs e)
        {
            dgvDanhSachSach.DataSource = muonsachBUS.Select();
            Lock();
        }
        void LuuChiTietMuonSach()
        {
            CTmuonsachDTO.MaPhieuMuon = txtMaPhieuMuon.Text;
            for (int i = 0; i < dgvDanhSachMuon.Rows.Count-1; i++)
            {
                CTmuonsachDTO.ChuThich = dgvDanhSachMuon.Rows[i].Cells[4].FormattedValue.ToString();

                CTmuonsachDTO.MaSach= dgvDanhSachMuon.Rows[i].Cells[0].FormattedValue.ToString();
                CTmuonsachBUS.Luu(CTmuonsachDTO);
                //MessageBox.Show("frm_MuonSach.LuuChiTietMuonSach: ChuThich:"+CTmuonsachDTO.ChuThich + "MaSach" + CTmuonsachDTO.MaSach+"MaPhieuMuon:"+ CTmuonsachDTO.MaPhieuMuon);                
            }
        }


    }
}

