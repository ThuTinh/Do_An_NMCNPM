﻿namespace DoAnNMCNPM_QuanLyThuVien.GUI
{
    partial class frm_MuonSach
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition1 = new Telerik.WinControls.UI.TableViewDefinition();
            this.radGroupBox2 = new Telerik.WinControls.UI.RadGroupBox();
            this.dtNgayMuon = new Telerik.WinControls.UI.RadDateTimePicker();
            this.dtNgayDuKienTra = new Telerik.WinControls.UI.RadDateTimePicker();
            this.txtHoTen = new Telerik.WinControls.UI.RadTextBoxControl();
            this.txtMaThe = new Telerik.WinControls.UI.RadTextBox();
            this.txtMaPhieuMuon = new Telerik.WinControls.UI.RadTextBoxControl();
            this.txtMaThuThu = new Telerik.WinControls.UI.RadTextBoxControl();
            this.radLabel7 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel9 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radGroupBox1 = new Telerik.WinControls.UI.RadGroupBox();
            this.dgvDanhSachMuon = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.radGroupBox5 = new Telerik.WinControls.UI.RadGroupBox();
            this.btnLuu = new Telerik.WinControls.UI.RadButton();
            this.btnMuon = new Telerik.WinControls.UI.RadButton();
            this.btnHuyMuon = new Telerik.WinControls.UI.RadButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radGroupBox3 = new Telerik.WinControls.UI.RadGroupBox();
            this.dgvDanhSachSach = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.radGroupBox4 = new Telerik.WinControls.UI.RadGroupBox();
            this.btnThoat = new Telerik.WinControls.UI.RadButton();
            this.btnTimKiem = new Telerik.WinControls.UI.RadButton();
            this.txtTuCanTim = new Telerik.WinControls.UI.RadTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbTimKiemTheo = new Telerik.WinControls.UI.RadMultiColumnComboBox();
            this.radLabel8 = new Telerik.WinControls.UI.RadLabel();
            this.lblSoLuongSachDaMuon = new Telerik.WinControls.UI.RadLabel();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).BeginInit();
            this.radGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtNgayMuon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtNgayDuKienTra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHoTen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaThe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaPhieuMuon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaThuThu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox1)).BeginInit();
            this.radGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachMuon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox5)).BeginInit();
            this.radGroupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnLuu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMuon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnHuyMuon)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).BeginInit();
            this.radGroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachSach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox4)).BeginInit();
            this.radGroupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnThoat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTimKiem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTuCanTim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo.EditorControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo.EditorControl.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSoLuongSachDaMuon)).BeginInit();
            this.SuspendLayout();
            // 
            // radGroupBox2
            // 
            this.radGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.radGroupBox2.Controls.Add(this.dtNgayMuon);
            this.radGroupBox2.Controls.Add(this.dtNgayDuKienTra);
            this.radGroupBox2.Controls.Add(this.txtHoTen);
            this.radGroupBox2.Controls.Add(this.txtMaThe);
            this.radGroupBox2.Controls.Add(this.txtMaPhieuMuon);
            this.radGroupBox2.Controls.Add(this.txtMaThuThu);
            this.radGroupBox2.Controls.Add(this.radLabel7);
            this.radGroupBox2.Controls.Add(this.radLabel1);
            this.radGroupBox2.Controls.Add(this.radLabel9);
            this.radGroupBox2.Controls.Add(this.radLabel6);
            this.radGroupBox2.Controls.Add(this.radLabel2);
            this.radGroupBox2.Controls.Add(this.lblSoLuongSachDaMuon);
            this.radGroupBox2.Controls.Add(this.radLabel5);
            this.radGroupBox2.Controls.Add(this.radLabel3);
            this.radGroupBox2.Controls.Add(this.radLabel4);
            this.radGroupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.radGroupBox2.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox2.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox2.HeaderText = "Thông tin";
            this.radGroupBox2.Location = new System.Drawing.Point(0, 0);
            this.radGroupBox2.Name = "radGroupBox2";
            this.radGroupBox2.Size = new System.Drawing.Size(509, 279);
            this.radGroupBox2.TabIndex = 4;
            this.radGroupBox2.Text = "Thông tin";
            // 
            // dtNgayMuon
            // 
            this.dtNgayMuon.Cursor = System.Windows.Forms.Cursors.Default;
            this.dtNgayMuon.CustomFormat = "";
            this.dtNgayMuon.Enabled = false;
            this.dtNgayMuon.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNgayMuon.Location = new System.Drawing.Point(160, 180);
            this.dtNgayMuon.Name = "dtNgayMuon";
            this.dtNgayMuon.Size = new System.Drawing.Size(215, 20);
            this.dtNgayMuon.TabIndex = 38;
            this.dtNgayMuon.TabStop = false;
            this.dtNgayMuon.Text = "28/04/2018";
            this.dtNgayMuon.Value = new System.DateTime(2018, 4, 28, 14, 46, 6, 0);
            // 
            // dtNgayDuKienTra
            // 
            this.dtNgayDuKienTra.CustomFormat = "";
            this.dtNgayDuKienTra.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNgayDuKienTra.Location = new System.Drawing.Point(160, 213);
            this.dtNgayDuKienTra.Name = "dtNgayDuKienTra";
            this.dtNgayDuKienTra.Size = new System.Drawing.Size(215, 20);
            this.dtNgayDuKienTra.TabIndex = 38;
            this.dtNgayDuKienTra.TabStop = false;
            this.dtNgayDuKienTra.Text = "27/04/2018";
            this.dtNgayDuKienTra.Value = new System.DateTime(2018, 4, 27, 0, 0, 0, 0);
            // 
            // txtHoTen
            // 
            this.txtHoTen.AccessibleDescription = "";
            this.txtHoTen.AccessibleName = "";
            this.txtHoTen.Enabled = false;
            this.txtHoTen.Location = new System.Drawing.Point(160, 146);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(215, 20);
            this.txtHoTen.TabIndex = 36;
            // 
            // txtMaThe
            // 
            this.txtMaThe.Enabled = false;
            this.txtMaThe.Location = new System.Drawing.Point(160, 113);
            this.txtMaThe.Name = "txtMaThe";
            this.txtMaThe.Size = new System.Drawing.Size(215, 20);
            this.txtMaThe.TabIndex = 35;
            // 
            // txtMaPhieuMuon
            // 
            this.txtMaPhieuMuon.Enabled = false;
            this.txtMaPhieuMuon.Location = new System.Drawing.Point(160, 50);
            this.txtMaPhieuMuon.Name = "txtMaPhieuMuon";
            this.txtMaPhieuMuon.Size = new System.Drawing.Size(215, 20);
            this.txtMaPhieuMuon.TabIndex = 34;
            // 
            // txtMaThuThu
            // 
            this.txtMaThuThu.Enabled = false;
            this.txtMaThuThu.Location = new System.Drawing.Point(160, 80);
            this.txtMaThuThu.Name = "txtMaThuThu";
            this.txtMaThuThu.Size = new System.Drawing.Size(215, 20);
            this.txtMaThuThu.TabIndex = 34;
            // 
            // radLabel7
            // 
            this.radLabel7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel7.Location = new System.Drawing.Point(21, 47);
            this.radLabel7.Name = "radLabel7";
            this.radLabel7.Size = new System.Drawing.Size(112, 19);
            this.radLabel7.TabIndex = 32;
            this.radLabel7.Text = "Mã phiếu mượn";
            // 
            // radLabel1
            // 
            this.radLabel1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel1.Location = new System.Drawing.Point(21, 79);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(81, 19);
            this.radLabel1.TabIndex = 26;
            this.radLabel1.Text = "Mã thủ thư";
            // 
            // radLabel9
            // 
            this.radLabel9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel9.Location = new System.Drawing.Point(22, 253);
            this.radLabel9.Name = "radLabel9";
            this.radLabel9.Size = new System.Drawing.Size(171, 19);
            this.radLabel9.TabIndex = 31;
            this.radLabel9.Text = "Số Lượng Sách Đã Mượn";
            // 
            // radLabel6
            // 
            this.radLabel6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel6.Location = new System.Drawing.Point(21, 215);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(119, 19);
            this.radLabel6.TabIndex = 31;
            this.radLabel6.Text = "Ngày dự kiến trả";
            // 
            // radLabel2
            // 
            this.radLabel2.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel2.Location = new System.Drawing.Point(19, 130);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(2, 2);
            this.radLabel2.TabIndex = 27;
            // 
            // radLabel5
            // 
            this.radLabel5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel5.Location = new System.Drawing.Point(21, 146);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(51, 19);
            this.radLabel5.TabIndex = 30;
            this.radLabel5.Text = "Họ tên";
            // 
            // radLabel3
            // 
            this.radLabel3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel3.Location = new System.Drawing.Point(22, 113);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(53, 19);
            this.radLabel3.TabIndex = 28;
            this.radLabel3.Text = "Mã thẻ";
            // 
            // radLabel4
            // 
            this.radLabel4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel4.Location = new System.Drawing.Point(21, 180);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(85, 19);
            this.radLabel4.TabIndex = 29;
            this.radLabel4.Text = "Ngày mượn";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radGroupBox1);
            this.panel1.Controls.Add(this.radGroupBox2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(509, 560);
            this.panel1.TabIndex = 5;
            // 
            // radGroupBox1
            // 
            this.radGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox1.Controls.Add(this.dgvDanhSachMuon);
            this.radGroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radGroupBox1.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox1.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox1.HeaderText = "Danh sách mượn";
            this.radGroupBox1.Location = new System.Drawing.Point(0, 279);
            this.radGroupBox1.Name = "radGroupBox1";
            this.radGroupBox1.Size = new System.Drawing.Size(509, 281);
            this.radGroupBox1.TabIndex = 5;
            this.radGroupBox1.Text = "Danh sách mượn";
            // 
            // dgvDanhSachMuon
            // 
            this.dgvDanhSachMuon.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvDanhSachMuon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvDanhSachMuon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachMuon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column13});
            this.dgvDanhSachMuon.Location = new System.Drawing.Point(2, 18);
            this.dgvDanhSachMuon.Name = "dgvDanhSachMuon";
            this.dgvDanhSachMuon.Size = new System.Drawing.Size(505, 261);
            this.dgvDanhSachMuon.TabIndex = 2;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.DataPropertyName = "MaSach";
            this.Column2.HeaderText = "Mã sách";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.DataPropertyName = "TenDauSach";
            this.Column3.HeaderText = "Tên sách";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.DataPropertyName = "TenTheLoai";
            this.Column4.HeaderText = "Thể loại";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column5.DataPropertyName = "TacGia";
            this.Column5.HeaderText = "Tác giả";
            this.Column5.Name = "Column5";
            // 
            // Column13
            // 
            this.Column13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column13.DataPropertyName = "ChuThich";
            this.Column13.HeaderText = "Ghi chú";
            this.Column13.Name = "Column13";
            // 
            // radGroupBox5
            // 
            this.radGroupBox5.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.radGroupBox5.Controls.Add(this.btnLuu);
            this.radGroupBox5.Controls.Add(this.btnMuon);
            this.radGroupBox5.Controls.Add(this.btnHuyMuon);
            this.radGroupBox5.Dock = System.Windows.Forms.DockStyle.Left;
            this.radGroupBox5.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox5.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox5.HeaderText = "Tác vụ";
            this.radGroupBox5.Location = new System.Drawing.Point(509, 0);
            this.radGroupBox5.Name = "radGroupBox5";
            this.radGroupBox5.Size = new System.Drawing.Size(181, 560);
            this.radGroupBox5.TabIndex = 7;
            this.radGroupBox5.Text = "Tác vụ";
            // 
            // btnLuu
            // 
            this.btnLuu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLuu.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnLuu.ForeColor = System.Drawing.Color.Black;
            this.btnLuu.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.Save_icon;
            this.btnLuu.Location = new System.Drawing.Point(28, 357);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(127, 53);
            this.btnLuu.TabIndex = 5;
            this.btnLuu.Text = "     LƯU";
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click_1);
            // 
            // btnMuon
            // 
            this.btnMuon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMuon.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnMuon.ForeColor = System.Drawing.Color.Black;
            this.btnMuon.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.Book_icon;
            this.btnMuon.Location = new System.Drawing.Point(28, 178);
            this.btnMuon.Name = "btnMuon";
            this.btnMuon.Size = new System.Drawing.Size(127, 52);
            this.btnMuon.TabIndex = 7;
            this.btnMuon.Text = "     MƯỢN";
            this.btnMuon.Click += new System.EventHandler(this.btnMuon_Click);
            // 
            // btnHuyMuon
            // 
            this.btnHuyMuon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHuyMuon.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnHuyMuon.ForeColor = System.Drawing.Color.Black;
            this.btnHuyMuon.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.delete_icon;
            this.btnHuyMuon.Location = new System.Drawing.Point(28, 267);
            this.btnHuyMuon.Name = "btnHuyMuon";
            this.btnHuyMuon.Size = new System.Drawing.Size(127, 52);
            this.btnHuyMuon.TabIndex = 8;
            this.btnHuyMuon.Text = "       HỦY MƯỢN";
            this.btnHuyMuon.Click += new System.EventHandler(this.btnHuyMuon_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radGroupBox3);
            this.panel2.Controls.Add(this.radGroupBox4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(690, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(577, 560);
            this.panel2.TabIndex = 8;
            // 
            // radGroupBox3
            // 
            this.radGroupBox3.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox3.Controls.Add(this.dgvDanhSachSach);
            this.radGroupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radGroupBox3.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox3.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox3.HeaderText = "Danh sách sách";
            this.radGroupBox3.Location = new System.Drawing.Point(0, 167);
            this.radGroupBox3.Name = "radGroupBox3";
            this.radGroupBox3.Size = new System.Drawing.Size(577, 393);
            this.radGroupBox3.TabIndex = 2;
            this.radGroupBox3.Text = "Danh sách sách";
            // 
            // dgvDanhSachSach
            // 
            this.dgvDanhSachSach.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvDanhSachSach.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvDanhSachSach.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvDanhSachSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachSach.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12});
            this.dgvDanhSachSach.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhSachSach.Location = new System.Drawing.Point(2, 18);
            this.dgvDanhSachSach.Name = "dgvDanhSachSach";
            this.dgvDanhSachSach.Size = new System.Drawing.Size(573, 373);
            this.dgvDanhSachSach.TabIndex = 3;
            this.dgvDanhSachSach.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDanhSachSach_CellClick);
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column7.DataPropertyName = "MaSach";
            this.Column7.HeaderText = "Mã sách";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column8.DataPropertyName = "TenDauSach";
            this.Column8.HeaderText = "Tên sách";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column9.DataPropertyName = "TenTheLoai";
            this.Column9.HeaderText = "Thể loại";
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            this.Column10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column10.DataPropertyName = "TacGia";
            this.Column10.HeaderText = "Tác giả";
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column11.DataPropertyName = "TinhTrang";
            this.Column11.HeaderText = "Tình trạng";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column12.DataPropertyName = "ChuThich";
            this.Column12.HeaderText = "Ghi chú";
            this.Column12.Name = "Column12";
            // 
            // radGroupBox4
            // 
            this.radGroupBox4.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.radGroupBox4.Controls.Add(this.btnThoat);
            this.radGroupBox4.Controls.Add(this.btnTimKiem);
            this.radGroupBox4.Controls.Add(this.txtTuCanTim);
            this.radGroupBox4.Controls.Add(this.label2);
            this.radGroupBox4.Controls.Add(this.cmbTimKiemTheo);
            this.radGroupBox4.Controls.Add(this.radLabel8);
            this.radGroupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.radGroupBox4.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox4.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox4.HeaderText = "Tìm kiếm nhanh";
            this.radGroupBox4.Location = new System.Drawing.Point(0, 0);
            this.radGroupBox4.Name = "radGroupBox4";
            this.radGroupBox4.Size = new System.Drawing.Size(577, 167);
            this.radGroupBox4.TabIndex = 1;
            this.radGroupBox4.Text = "Tìm kiếm nhanh";
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnThoat.ForeColor = System.Drawing.Color.Black;
            this.btnThoat.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.Search_Images_icon;
            this.btnThoat.Location = new System.Drawing.Point(427, 100);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(116, 33);
            this.btnThoat.TabIndex = 8;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTimKiem.ForeColor = System.Drawing.Color.Black;
            this.btnTimKiem.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.Search_Images_icon;
            this.btnTimKiem.Location = new System.Drawing.Point(126, 100);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(116, 33);
            this.btnTimKiem.TabIndex = 4;
            this.btnTimKiem.Text = "      Tìm kiếm";
            this.btnTimKiem.Click += new System.EventHandler(this.btnTimKiem_Click_1);
            // 
            // txtTuCanTim
            // 
            this.txtTuCanTim.Location = new System.Drawing.Point(427, 52);
            this.txtTuCanTim.Name = "txtTuCanTim";
            this.txtTuCanTim.Size = new System.Drawing.Size(142, 20);
            this.txtTuCanTim.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(330, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Từ cần tìm";
            // 
            // cmbTimKiemTheo
            // 
            this.cmbTimKiemTheo.AutoSize = false;
            // 
            // cmbTimKiemTheo.NestedRadGridView
            // 
            this.cmbTimKiemTheo.EditorControl.BackColor = System.Drawing.SystemColors.Window;
            this.cmbTimKiemTheo.EditorControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTimKiemTheo.EditorControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cmbTimKiemTheo.EditorControl.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.AllowAddNewRow = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.AllowCellContextMenu = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.AllowColumnChooser = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.EnableGrouping = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.ShowFilteringRow = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.ViewDefinition = tableViewDefinition1;
            this.cmbTimKiemTheo.EditorControl.Name = "NestedRadGridView";
            this.cmbTimKiemTheo.EditorControl.ReadOnly = true;
            this.cmbTimKiemTheo.EditorControl.ShowGroupPanel = false;
            this.cmbTimKiemTheo.EditorControl.Size = new System.Drawing.Size(240, 150);
            this.cmbTimKiemTheo.EditorControl.TabIndex = 0;
            this.cmbTimKiemTheo.Location = new System.Drawing.Point(126, 51);
            this.cmbTimKiemTheo.Name = "cmbTimKiemTheo";
            this.cmbTimKiemTheo.Size = new System.Drawing.Size(178, 22);
            this.cmbTimKiemTheo.TabIndex = 1;
            this.cmbTimKiemTheo.TabStop = false;
            // 
            // radLabel8
            // 
            this.radLabel8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel8.Location = new System.Drawing.Point(17, 50);
            this.radLabel8.Name = "radLabel8";
            this.radLabel8.Size = new System.Drawing.Size(103, 19);
            this.radLabel8.TabIndex = 0;
            this.radLabel8.Text = "Tìm kiếm theo";
            // 
            // lblSoLuongSachDaMuon
            // 
            this.lblSoLuongSachDaMuon.AutoSize = false;
            this.lblSoLuongSachDaMuon.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoLuongSachDaMuon.Location = new System.Drawing.Point(199, 254);
            this.lblSoLuongSachDaMuon.Name = "lblSoLuongSachDaMuon";
            this.lblSoLuongSachDaMuon.Size = new System.Drawing.Size(176, 19);
            this.lblSoLuongSachDaMuon.TabIndex = 30;
            // 
            // frm_MuonSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.radGroupBox5);
            this.Controls.Add(this.panel1);
            this.Name = "frm_MuonSach";
            this.Size = new System.Drawing.Size(1267, 560);
            this.Load += new System.EventHandler(this.frm_MuonSach_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).EndInit();
            this.radGroupBox2.ResumeLayout(false);
            this.radGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtNgayMuon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtNgayDuKienTra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHoTen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaThe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaPhieuMuon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaThuThu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox1)).EndInit();
            this.radGroupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachMuon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox5)).EndInit();
            this.radGroupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnLuu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMuon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnHuyMuon)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).EndInit();
            this.radGroupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachSach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox4)).EndInit();
            this.radGroupBox4.ResumeLayout(false);
            this.radGroupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnThoat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTimKiem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTuCanTim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo.EditorControl.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo.EditorControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblSoLuongSachDaMuon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Telerik.WinControls.UI.RadGroupBox radGroupBox2;
        private System.Windows.Forms.Panel panel1;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox1;
        private Telerik.WinControls.UI.RadTextBoxControl txtHoTen;
        private Telerik.WinControls.UI.RadTextBox txtMaThe;
        private Telerik.WinControls.UI.RadTextBoxControl txtMaThuThu;
        private Telerik.WinControls.UI.RadLabel radLabel7;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private System.Windows.Forms.DataGridView dgvDanhSachMuon;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox5;
        private System.Windows.Forms.Panel panel2;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox3;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox4;
        private System.Windows.Forms.DataGridView dgvDanhSachSach;
        private Telerik.WinControls.UI.RadButton btnHuyMuon;
        private Telerik.WinControls.UI.RadButton btnMuon;
        private Telerik.WinControls.UI.RadMultiColumnComboBox cmbTimKiemTheo;
        private Telerik.WinControls.UI.RadLabel radLabel8;
        private Telerik.WinControls.UI.RadTextBox txtTuCanTim;
        private System.Windows.Forms.Label label2;
        private Telerik.WinControls.UI.RadTextBoxControl txtMaPhieuMuon;
        private Telerik.WinControls.UI.RadDateTimePicker dtNgayDuKienTra;
        private Telerik.WinControls.UI.RadButton btnLuu;
        private Telerik.WinControls.UI.RadDateTimePicker dtNgayMuon;
        private Telerik.WinControls.UI.RadButton btnTimKiem;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private Telerik.WinControls.UI.RadButton btnThoat;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private Telerik.WinControls.UI.RadLabel radLabel9;
        private Telerik.WinControls.UI.RadLabel lblSoLuongSachDaMuon;
    }
}
