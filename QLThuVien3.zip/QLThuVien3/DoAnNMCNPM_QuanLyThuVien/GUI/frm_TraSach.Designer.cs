﻿namespace DoAnNMCNPM_QuanLyThuVien.GUI
{
    partial class frm_TraSach
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radGroupBox1 = new Telerik.WinControls.UI.RadGroupBox();
            this.lbTongTienPhat = new System.Windows.Forms.Label();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.dtNgayTra = new Telerik.WinControls.UI.RadDateTimePicker();
            this.txtTen = new Telerik.WinControls.UI.RadTextBoxControl();
            this.txtMaDocGia = new Telerik.WinControls.UI.RadTextBox();
            this.txtMaThuThu = new Telerik.WinControls.UI.RadTextBoxControl();
            this.txtMaPhieuTra = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.radGroupBox2 = new Telerik.WinControls.UI.RadGroupBox();
            this.btnTTSach = new Telerik.WinControls.UI.RadButton();
            this.btnLuu = new Telerik.WinControls.UI.RadButton();
            this.btnThanhToan = new Telerik.WinControls.UI.RadButton();
            this.btnHuyTra = new Telerik.WinControls.UI.RadButton();
            this.btnTraSach = new Telerik.WinControls.UI.RadButton();
            this.btnTTMuon = new Telerik.WinControls.UI.RadButton();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.radGroupBox4 = new Telerik.WinControls.UI.RadGroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radGroupBox3 = new Telerik.WinControls.UI.RadGroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox1)).BeginInit();
            this.radGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtNgayTra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaDocGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaThuThu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaPhieuTra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).BeginInit();
            this.radGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnTTSach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLuu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnThanhToan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnHuyTra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTraSach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTTMuon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox4)).BeginInit();
            this.radGroupBox4.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).BeginInit();
            this.radGroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // radGroupBox1
            // 
            this.radGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.radGroupBox1.Controls.Add(this.lbTongTienPhat);
            this.radGroupBox1.Controls.Add(this.radLabel6);
            this.radGroupBox1.Controls.Add(this.dtNgayTra);
            this.radGroupBox1.Controls.Add(this.txtTen);
            this.radGroupBox1.Controls.Add(this.txtMaDocGia);
            this.radGroupBox1.Controls.Add(this.txtMaThuThu);
            this.radGroupBox1.Controls.Add(this.txtMaPhieuTra);
            this.radGroupBox1.Controls.Add(this.radLabel5);
            this.radGroupBox1.Controls.Add(this.radLabel4);
            this.radGroupBox1.Controls.Add(this.radLabel3);
            this.radGroupBox1.Controls.Add(this.radLabel2);
            this.radGroupBox1.Controls.Add(this.radLabel1);
            this.radGroupBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.radGroupBox1.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox1.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox1.HeaderText = "Thông tin trả sách";
            this.radGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.radGroupBox1.Name = "radGroupBox1";
            this.radGroupBox1.Size = new System.Drawing.Size(386, 560);
            this.radGroupBox1.TabIndex = 0;
            this.radGroupBox1.Text = "Thông tin trả sách";
            // 
            // lbTongTienPhat
            // 
            this.lbTongTienPhat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbTongTienPhat.Enabled = false;
            this.lbTongTienPhat.Location = new System.Drawing.Point(144, 276);
            this.lbTongTienPhat.Name = "lbTongTienPhat";
            this.lbTongTienPhat.Size = new System.Drawing.Size(172, 20);
            this.lbTongTienPhat.TabIndex = 14;
            // 
            // radLabel6
            // 
            this.radLabel6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel6.Location = new System.Drawing.Point(28, 274);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(105, 19);
            this.radLabel6.TabIndex = 13;
            this.radLabel6.Text = "Tổng tiền phạt";
            // 
            // dtNgayTra
            // 
            this.dtNgayTra.Enabled = false;
            this.dtNgayTra.Location = new System.Drawing.Point(144, 229);
            this.dtNgayTra.Name = "dtNgayTra";
            this.dtNgayTra.Size = new System.Drawing.Size(172, 20);
            this.dtNgayTra.TabIndex = 11;
            this.dtNgayTra.TabStop = false;
            this.dtNgayTra.Text = "26 March 2018";
            this.dtNgayTra.Value = new System.DateTime(2018, 3, 26, 21, 40, 31, 393);
            // 
            // txtTen
            // 
            this.txtTen.Enabled = false;
            this.txtTen.Location = new System.Drawing.Point(144, 184);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(172, 20);
            this.txtTen.TabIndex = 10;
            // 
            // txtMaDocGia
            // 
            this.txtMaDocGia.Enabled = false;
            this.txtMaDocGia.Location = new System.Drawing.Point(144, 140);
            this.txtMaDocGia.Name = "txtMaDocGia";
            this.txtMaDocGia.Size = new System.Drawing.Size(172, 20);
            this.txtMaDocGia.TabIndex = 9;
            // 
            // txtMaThuThu
            // 
            this.txtMaThuThu.Enabled = false;
            this.txtMaThuThu.Location = new System.Drawing.Point(144, 96);
            this.txtMaThuThu.Name = "txtMaThuThu";
            this.txtMaThuThu.Size = new System.Drawing.Size(172, 20);
            this.txtMaThuThu.TabIndex = 8;
            // 
            // txtMaPhieuTra
            // 
            this.txtMaPhieuTra.Enabled = false;
            this.txtMaPhieuTra.Location = new System.Drawing.Point(144, 53);
            this.txtMaPhieuTra.Name = "txtMaPhieuTra";
            this.txtMaPhieuTra.Size = new System.Drawing.Size(172, 20);
            this.txtMaPhieuTra.TabIndex = 7;
            // 
            // radLabel5
            // 
            this.radLabel5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel5.Location = new System.Drawing.Point(28, 230);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(65, 19);
            this.radLabel5.TabIndex = 5;
            this.radLabel5.Text = "Ngày trả";
            // 
            // radLabel4
            // 
            this.radLabel4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel4.Location = new System.Drawing.Point(28, 184);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(35, 19);
            this.radLabel4.TabIndex = 4;
            this.radLabel4.Text = "Tên ";
            // 
            // radLabel3
            // 
            this.radLabel3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel3.Location = new System.Drawing.Point(28, 140);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(79, 19);
            this.radLabel3.TabIndex = 3;
            this.radLabel3.Text = "Mã độc giả";
            // 
            // radLabel2
            // 
            this.radLabel2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel2.Location = new System.Drawing.Point(28, 97);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(81, 19);
            this.radLabel2.TabIndex = 2;
            this.radLabel2.Text = "Mã thủ thư";
            // 
            // radLabel1
            // 
            this.radLabel1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel1.Location = new System.Drawing.Point(28, 54);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(92, 19);
            this.radLabel1.TabIndex = 1;
            this.radLabel1.Text = "Mã phiếu trả";
            // 
            // radGroupBox2
            // 
            this.radGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.radGroupBox2.Controls.Add(this.btnTTSach);
            this.radGroupBox2.Controls.Add(this.btnLuu);
            this.radGroupBox2.Controls.Add(this.btnThanhToan);
            this.radGroupBox2.Controls.Add(this.btnHuyTra);
            this.radGroupBox2.Controls.Add(this.btnTraSach);
            this.radGroupBox2.Controls.Add(this.btnTTMuon);
            this.radGroupBox2.Dock = System.Windows.Forms.DockStyle.Left;
            this.radGroupBox2.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox2.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox2.HeaderText = "Tác vụ";
            this.radGroupBox2.Location = new System.Drawing.Point(386, 0);
            this.radGroupBox2.Name = "radGroupBox2";
            this.radGroupBox2.Size = new System.Drawing.Size(203, 560);
            this.radGroupBox2.TabIndex = 1;
            this.radGroupBox2.Text = "Tác vụ";
            // 
            // btnTTSach
            // 
            this.btnTTSach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTTSach.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTTSach.ForeColor = System.Drawing.Color.Black;
            this.btnTTSach.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.edit_icon;
            this.btnTTSach.Location = new System.Drawing.Point(28, 472);
            this.btnTTSach.Name = "btnTTSach";
            this.btnTTSach.Size = new System.Drawing.Size(148, 53);
            this.btnTTSach.TabIndex = 5;
            this.btnTTSach.Text = "  TT SÁCH";
            // 
            // btnLuu
            // 
            this.btnLuu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLuu.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnLuu.ForeColor = System.Drawing.Color.Black;
            this.btnLuu.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.Save_icon;
            this.btnLuu.Location = new System.Drawing.Point(28, 389);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(148, 53);
            this.btnLuu.TabIndex = 5;
            this.btnLuu.Text = "  LƯU";
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThanhToan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnThanhToan.ForeColor = System.Drawing.Color.Black;
            this.btnThanhToan.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.cart_icon;
            this.btnThanhToan.Location = new System.Drawing.Point(28, 306);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(148, 53);
            this.btnThanhToan.TabIndex = 9;
            this.btnThanhToan.Text = "      THANH TOÁN";
            // 
            // btnHuyTra
            // 
            this.btnHuyTra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHuyTra.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnHuyTra.ForeColor = System.Drawing.Color.Black;
            this.btnHuyTra.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.delete_icon;
            this.btnHuyTra.Location = new System.Drawing.Point(28, 221);
            this.btnHuyTra.Name = "btnHuyTra";
            this.btnHuyTra.Size = new System.Drawing.Size(148, 53);
            this.btnHuyTra.TabIndex = 8;
            this.btnHuyTra.Text = "HỦY TRẢ";
            // 
            // btnTraSach
            // 
            this.btnTraSach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTraSach.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTraSach.ForeColor = System.Drawing.Color.Black;
            this.btnTraSach.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.books_icon;
            this.btnTraSach.Location = new System.Drawing.Point(28, 135);
            this.btnTraSach.Name = "btnTraSach";
            this.btnTraSach.Size = new System.Drawing.Size(148, 53);
            this.btnTraSach.TabIndex = 7;
            this.btnTraSach.Text = "    TRẢ SÁCH";
            // 
            // btnTTMuon
            // 
            this.btnTTMuon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTTMuon.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTTMuon.ForeColor = System.Drawing.Color.Black;
            this.btnTTMuon.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.windows_users_icon;
            this.btnTTMuon.Location = new System.Drawing.Point(28, 57);
            this.btnTTMuon.Name = "btnTTMuon";
            this.btnTTMuon.Size = new System.Drawing.Size(148, 53);
            this.btnTTMuon.TabIndex = 6;
            this.btnTTMuon.Text = "   TT MƯỢN";
            this.btnTTMuon.Click += new System.EventHandler(this.btnTTMuon_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column13,
            this.Column12});
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(2, 18);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(531, 286);
            this.dataGridView2.TabIndex = 0;
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column5.HeaderText = "STT";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column6.HeaderText = "Mã phiếu mượn";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column7.HeaderText = "Mã sách";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column8.HeaderText = "Tên sách";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column9.HeaderText = "Thể loại";
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            this.Column10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column10.HeaderText = "Tác giả";
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column11.HeaderText = "Ngày mượn";
            this.Column11.Name = "Column11";
            // 
            // Column13
            // 
            this.Column13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column13.HeaderText = "Số ngày trả muộn";
            this.Column13.Name = "Column13";
            // 
            // Column12
            // 
            this.Column12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column12.HeaderText = "Tình trạng trả";
            this.Column12.Name = "Column12";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column14,
            this.Column4,
            this.Column15});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(2, 18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(531, 234);
            this.dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "STT";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "Mã phiếu mượn";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "Mã sách";
            this.Column3.Name = "Column3";
            // 
            // Column14
            // 
            this.Column14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column14.HeaderText = "Tên Sách";
            this.Column14.Name = "Column14";
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.HeaderText = "Ngày mượn";
            this.Column4.Name = "Column4";
            // 
            // Column15
            // 
            this.Column15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column15.HeaderText = "Tình trạng mượn";
            this.Column15.Name = "Column15";
            // 
            // radGroupBox4
            // 
            this.radGroupBox4.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox4.Controls.Add(this.dataGridView1);
            this.radGroupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.radGroupBox4.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox4.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox4.HeaderText = "Thông tin sách đã mượn";
            this.radGroupBox4.Location = new System.Drawing.Point(0, 0);
            this.radGroupBox4.Name = "radGroupBox4";
            this.radGroupBox4.Size = new System.Drawing.Size(535, 254);
            this.radGroupBox4.TabIndex = 2;
            this.radGroupBox4.Text = "Thông tin sách đã mượn";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radGroupBox3);
            this.panel1.Controls.Add(this.radGroupBox4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(589, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(535, 560);
            this.panel1.TabIndex = 2;
            // 
            // radGroupBox3
            // 
            this.radGroupBox3.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox3.Controls.Add(this.dataGridView2);
            this.radGroupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radGroupBox3.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox3.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox3.HeaderText = "Thông tin sách trả";
            this.radGroupBox3.Location = new System.Drawing.Point(0, 254);
            this.radGroupBox3.Name = "radGroupBox3";
            this.radGroupBox3.Size = new System.Drawing.Size(535, 306);
            this.radGroupBox3.TabIndex = 3;
            this.radGroupBox3.Text = "Thông tin sách trả";
            // 
            // frm_TraSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.radGroupBox2);
            this.Controls.Add(this.radGroupBox1);
            this.Name = "frm_TraSach";
            this.Size = new System.Drawing.Size(1124, 560);
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox1)).EndInit();
            this.radGroupBox1.ResumeLayout(false);
            this.radGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtNgayTra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaDocGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaThuThu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaPhieuTra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).EndInit();
            this.radGroupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnTTSach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLuu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnThanhToan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnHuyTra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTraSach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnTTMuon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox4)).EndInit();
            this.radGroupBox4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).EndInit();
            this.radGroupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadGroupBox radGroupBox1;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox2;
        private Telerik.WinControls.UI.RadDateTimePicker dtNgayTra;
        private Telerik.WinControls.UI.RadTextBoxControl txtTen;
        private Telerik.WinControls.UI.RadTextBox txtMaDocGia;
        private Telerik.WinControls.UI.RadTextBoxControl txtMaThuThu;
        private Telerik.WinControls.UI.RadTextBox txtMaPhieuTra;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadButton btnThanhToan;
        private Telerik.WinControls.UI.RadButton btnHuyTra;
        private Telerik.WinControls.UI.RadButton btnTraSach;
        private Telerik.WinControls.UI.RadButton btnTTMuon;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private System.Windows.Forms.DataGridView dataGridView2;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox4;
        private System.Windows.Forms.Panel panel1;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private Telerik.WinControls.UI.RadButton btnLuu;
        private Telerik.WinControls.UI.RadButton btnTTSach;
        private System.Windows.Forms.Label lbTongTienPhat;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
    }
}
