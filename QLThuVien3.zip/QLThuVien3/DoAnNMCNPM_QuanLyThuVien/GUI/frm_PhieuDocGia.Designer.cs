﻿namespace DoAnNMCNPM_QuanLyThuVien.GUI
{
    partial class frm_PhieuDocGia
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition1 = new Telerik.WinControls.UI.TableViewDefinition();
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition2 = new Telerik.WinControls.UI.TableViewDefinition();
            this.radGroupBox1 = new Telerik.WinControls.UI.RadGroupBox();
            this.dtNgayLamThe = new Telerik.WinControls.UI.RadDateTimePicker();
            this.dthanThe = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel7 = new Telerik.WinControls.UI.RadLabel();
            this.cmbLoaiThe = new Telerik.WinControls.UI.RadMultiColumnComboBox();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.txtHoTen = new Telerik.WinControls.UI.RadTextBox();
            this.txtMaDocGia = new Telerik.WinControls.UI.RadTextBoxControl();
            this.txtMaThe = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.radGroupBox2 = new Telerik.WinControls.UI.RadGroupBox();
            this.btnCapNhap = new Telerik.WinControls.UI.RadButton();
            this.btnXoa = new Telerik.WinControls.UI.RadButton();
            this.btnThem = new Telerik.WinControls.UI.RadButton();
            this.btnLuu = new Telerik.WinControls.UI.RadButton();
            this.radGroupBox3 = new Telerik.WinControls.UI.RadGroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radGroupBox4 = new Telerik.WinControls.UI.RadGroupBox();
            this.cmbTimKiem = new Telerik.WinControls.UI.RadButton();
            this.txtTuCanTim = new Telerik.WinControls.UI.RadTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbTimKiemTheo = new Telerik.WinControls.UI.RadMultiColumnComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtNgaySinh = new Telerik.WinControls.UI.RadDateTimePicker();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox1)).BeginInit();
            this.radGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtNgayLamThe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dthanThe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLoaiThe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLoaiThe.EditorControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLoaiThe.EditorControl.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHoTen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaDocGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaThe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).BeginInit();
            this.radGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnCapNhap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnXoa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnThem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLuu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).BeginInit();
            this.radGroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox4)).BeginInit();
            this.radGroupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTuCanTim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo.EditorControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo.EditorControl.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtNgaySinh)).BeginInit();
            this.SuspendLayout();
            // 
            // radGroupBox1
            // 
            this.radGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox1.Controls.Add(this.dtNgaySinh);
            this.radGroupBox1.Controls.Add(this.dtNgayLamThe);
            this.radGroupBox1.Controls.Add(this.dthanThe);
            this.radGroupBox1.Controls.Add(this.radLabel7);
            this.radGroupBox1.Controls.Add(this.cmbLoaiThe);
            this.radGroupBox1.Controls.Add(this.radLabel6);
            this.radGroupBox1.Controls.Add(this.txtHoTen);
            this.radGroupBox1.Controls.Add(this.txtMaDocGia);
            this.radGroupBox1.Controls.Add(this.txtMaThe);
            this.radGroupBox1.Controls.Add(this.radLabel5);
            this.radGroupBox1.Controls.Add(this.radLabel4);
            this.radGroupBox1.Controls.Add(this.radLabel3);
            this.radGroupBox1.Controls.Add(this.radLabel2);
            this.radGroupBox1.Controls.Add(this.radLabel1);
            this.radGroupBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.radGroupBox1.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox1.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox1.HeaderText = "Thông tin";
            this.radGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.radGroupBox1.Name = "radGroupBox1";
            this.radGroupBox1.Size = new System.Drawing.Size(408, 560);
            this.radGroupBox1.TabIndex = 0;
            this.radGroupBox1.Text = "Thông tin";
            // 
            // dtNgayLamThe
            // 
            this.dtNgayLamThe.Location = new System.Drawing.Point(131, 263);
            this.dtNgayLamThe.Name = "dtNgayLamThe";
            this.dtNgayLamThe.Size = new System.Drawing.Size(194, 20);
            this.dtNgayLamThe.TabIndex = 40;
            this.dtNgayLamThe.TabStop = false;
            this.dtNgayLamThe.Text = "Sunday, April 22, 2018";
            this.dtNgayLamThe.Value = new System.DateTime(2018, 4, 22, 22, 55, 49, 186);
            // 
            // dthanThe
            // 
            this.dthanThe.Location = new System.Drawing.Point(131, 316);
            this.dthanThe.Name = "dthanThe";
            this.dthanThe.Size = new System.Drawing.Size(194, 20);
            this.dthanThe.TabIndex = 39;
            this.dthanThe.TabStop = false;
            this.dthanThe.Text = "Sunday, April 22, 2018";
            this.dthanThe.Value = new System.DateTime(2018, 4, 22, 22, 55, 49, 186);
            // 
            // radLabel7
            // 
            this.radLabel7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel7.Location = new System.Drawing.Point(25, 160);
            this.radLabel7.Name = "radLabel7";
            this.radLabel7.Size = new System.Drawing.Size(51, 19);
            this.radLabel7.TabIndex = 15;
            this.radLabel7.Text = "Họ tên";
            // 
            // cmbLoaiThe
            // 
            // 
            // cmbLoaiThe.NestedRadGridView
            // 
            this.cmbLoaiThe.EditorControl.BackColor = System.Drawing.SystemColors.Window;
            this.cmbLoaiThe.EditorControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLoaiThe.EditorControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cmbLoaiThe.EditorControl.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.cmbLoaiThe.EditorControl.MasterTemplate.AllowAddNewRow = false;
            this.cmbLoaiThe.EditorControl.MasterTemplate.AllowCellContextMenu = false;
            this.cmbLoaiThe.EditorControl.MasterTemplate.AllowColumnChooser = false;
            this.cmbLoaiThe.EditorControl.MasterTemplate.EnableGrouping = false;
            this.cmbLoaiThe.EditorControl.MasterTemplate.ShowFilteringRow = false;
            this.cmbLoaiThe.EditorControl.MasterTemplate.ViewDefinition = tableViewDefinition1;
            this.cmbLoaiThe.EditorControl.Name = "NestedRadGridView";
            this.cmbLoaiThe.EditorControl.ReadOnly = true;
            this.cmbLoaiThe.EditorControl.ShowGroupPanel = false;
            this.cmbLoaiThe.EditorControl.Size = new System.Drawing.Size(240, 150);
            this.cmbLoaiThe.EditorControl.TabIndex = 0;
            this.cmbLoaiThe.Location = new System.Drawing.Point(131, 367);
            this.cmbLoaiThe.Name = "cmbLoaiThe";
            this.cmbLoaiThe.Size = new System.Drawing.Size(194, 20);
            this.cmbLoaiThe.TabIndex = 13;
            this.cmbLoaiThe.TabStop = false;
            // 
            // radLabel6
            // 
            this.radLabel6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel6.Location = new System.Drawing.Point(25, 212);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(73, 19);
            this.radLabel6.TabIndex = 11;
            this.radLabel6.Text = "Ngày sinh";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(131, 162);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(194, 20);
            this.txtHoTen.TabIndex = 8;
            // 
            // txtMaDocGia
            // 
            this.txtMaDocGia.Location = new System.Drawing.Point(131, 111);
            this.txtMaDocGia.Name = "txtMaDocGia";
            this.txtMaDocGia.Size = new System.Drawing.Size(194, 20);
            this.txtMaDocGia.TabIndex = 7;
            // 
            // txtMaThe
            // 
            this.txtMaThe.Location = new System.Drawing.Point(131, 59);
            this.txtMaThe.Name = "txtMaThe";
            this.txtMaThe.Size = new System.Drawing.Size(194, 20);
            this.txtMaThe.TabIndex = 6;
            // 
            // radLabel5
            // 
            this.radLabel5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel5.Location = new System.Drawing.Point(25, 366);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(61, 19);
            this.radLabel5.TabIndex = 4;
            this.radLabel5.Text = "Loại thẻ";
            // 
            // radLabel4
            // 
            this.radLabel4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel4.Location = new System.Drawing.Point(25, 315);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(60, 19);
            this.radLabel4.TabIndex = 3;
            this.radLabel4.Text = "Hạn thẻ";
            // 
            // radLabel3
            // 
            this.radLabel3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel3.Location = new System.Drawing.Point(25, 263);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(96, 19);
            this.radLabel3.TabIndex = 2;
            this.radLabel3.Text = "Ngày làm thẻ";
            // 
            // radLabel2
            // 
            this.radLabel2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel2.Location = new System.Drawing.Point(25, 110);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(79, 19);
            this.radLabel2.TabIndex = 1;
            this.radLabel2.Text = "Mã độc giả";
            // 
            // radLabel1
            // 
            this.radLabel1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.radLabel1.Location = new System.Drawing.Point(25, 59);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(53, 19);
            this.radLabel1.TabIndex = 0;
            this.radLabel1.Text = "Mã thẻ";
            // 
            // radGroupBox2
            // 
            this.radGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox2.Controls.Add(this.btnCapNhap);
            this.radGroupBox2.Controls.Add(this.btnXoa);
            this.radGroupBox2.Controls.Add(this.btnThem);
            this.radGroupBox2.Controls.Add(this.btnLuu);
            this.radGroupBox2.Dock = System.Windows.Forms.DockStyle.Left;
            this.radGroupBox2.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox2.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox2.HeaderText = "Tác vụ";
            this.radGroupBox2.Location = new System.Drawing.Point(408, 0);
            this.radGroupBox2.Name = "radGroupBox2";
            this.radGroupBox2.Size = new System.Drawing.Size(184, 560);
            this.radGroupBox2.TabIndex = 1;
            this.radGroupBox2.Text = "Tác vụ";
            // 
            // btnCapNhap
            // 
            this.btnCapNhap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCapNhap.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnCapNhap.ForeColor = System.Drawing.Color.Black;
            this.btnCapNhap.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.Text_Edit_icon;
            this.btnCapNhap.Location = new System.Drawing.Point(29, 302);
            this.btnCapNhap.Name = "btnCapNhap";
            this.btnCapNhap.Size = new System.Drawing.Size(127, 53);
            this.btnCapNhap.TabIndex = 7;
            this.btnCapNhap.Text = "       CẬP NHẬP";
            // 
            // btnXoa
            // 
            this.btnXoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnXoa.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnXoa.ForeColor = System.Drawing.Color.Black;
            this.btnXoa.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.delete_file_icon;
            this.btnXoa.Location = new System.Drawing.Point(29, 204);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(127, 53);
            this.btnXoa.TabIndex = 6;
            this.btnXoa.Text = "    XÓA";
            // 
            // btnThem
            // 
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThem.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnThem.ForeColor = System.Drawing.Color.Black;
            this.btnThem.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.add_contact_icon;
            this.btnThem.Location = new System.Drawing.Point(29, 107);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(127, 53);
            this.btnThem.TabIndex = 5;
            this.btnThem.Text = "     THÊM";
            // 
            // btnLuu
            // 
            this.btnLuu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLuu.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnLuu.ForeColor = System.Drawing.Color.Black;
            this.btnLuu.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.Save_icon;
            this.btnLuu.Location = new System.Drawing.Point(29, 401);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(127, 53);
            this.btnLuu.TabIndex = 4;
            this.btnLuu.Text = "     LƯU";
            // 
            // radGroupBox3
            // 
            this.radGroupBox3.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox3.Controls.Add(this.dataGridView1);
            this.radGroupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radGroupBox3.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox3.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox3.HeaderText = "Danh sách thẻ độc giả";
            this.radGroupBox3.Location = new System.Drawing.Point(0, 169);
            this.radGroupBox3.Name = "radGroupBox3";
            this.radGroupBox3.Size = new System.Drawing.Size(532, 391);
            this.radGroupBox3.TabIndex = 2;
            this.radGroupBox3.Text = "Danh sách thẻ độc giả";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column8,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(2, 18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(528, 371);
            this.dataGridView1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radGroupBox3);
            this.panel1.Controls.Add(this.radGroupBox4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(592, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(532, 560);
            this.panel1.TabIndex = 2;
            // 
            // radGroupBox4
            // 
            this.radGroupBox4.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox4.Controls.Add(this.cmbTimKiem);
            this.radGroupBox4.Controls.Add(this.txtTuCanTim);
            this.radGroupBox4.Controls.Add(this.label2);
            this.radGroupBox4.Controls.Add(this.cmbTimKiemTheo);
            this.radGroupBox4.Controls.Add(this.label1);
            this.radGroupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.radGroupBox4.Font = new System.Drawing.Font("Segoe UI", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.radGroupBox4.GroupBoxStyle = Telerik.WinControls.UI.RadGroupBoxStyle.Office;
            this.radGroupBox4.HeaderText = "Tìm kiếm nhanh";
            this.radGroupBox4.Location = new System.Drawing.Point(0, 0);
            this.radGroupBox4.Name = "radGroupBox4";
            this.radGroupBox4.Size = new System.Drawing.Size(532, 169);
            this.radGroupBox4.TabIndex = 4;
            this.radGroupBox4.Text = "Tìm kiếm nhanh";
            // 
            // cmbTimKiem
            // 
            this.cmbTimKiem.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.cmbTimKiem.ForeColor = System.Drawing.Color.Black;
            this.cmbTimKiem.Image = global::DoAnNMCNPM_QuanLyThuVien.Properties.Resources.Search_Images_icon;
            this.cmbTimKiem.Location = new System.Drawing.Point(130, 96);
            this.cmbTimKiem.Name = "cmbTimKiem";
            this.cmbTimKiem.Size = new System.Drawing.Size(116, 33);
            this.cmbTimKiem.TabIndex = 4;
            this.cmbTimKiem.Text = "      Tìm kiếm";
            // 
            // txtTuCanTim
            // 
            this.txtTuCanTim.Location = new System.Drawing.Point(437, 46);
            this.txtTuCanTim.Name = "txtTuCanTim";
            this.txtTuCanTim.Size = new System.Drawing.Size(127, 20);
            this.txtTuCanTim.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(350, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = "Từ cần tìm";
            // 
            // cmbTimKiemTheo
            // 
            // 
            // cmbTimKiemTheo.NestedRadGridView
            // 
            this.cmbTimKiemTheo.EditorControl.BackColor = System.Drawing.SystemColors.Window;
            this.cmbTimKiemTheo.EditorControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTimKiemTheo.EditorControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cmbTimKiemTheo.EditorControl.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.AllowAddNewRow = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.AllowCellContextMenu = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.AllowColumnChooser = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.EnableGrouping = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.ShowFilteringRow = false;
            this.cmbTimKiemTheo.EditorControl.MasterTemplate.ViewDefinition = tableViewDefinition2;
            this.cmbTimKiemTheo.EditorControl.Name = "NestedRadGridView";
            this.cmbTimKiemTheo.EditorControl.ReadOnly = true;
            this.cmbTimKiemTheo.EditorControl.ShowGroupPanel = false;
            this.cmbTimKiemTheo.EditorControl.Size = new System.Drawing.Size(240, 150);
            this.cmbTimKiemTheo.EditorControl.TabIndex = 0;
            this.cmbTimKiemTheo.Location = new System.Drawing.Point(130, 48);
            this.cmbTimKiemTheo.Name = "cmbTimKiemTheo";
            this.cmbTimKiemTheo.Size = new System.Drawing.Size(172, 20);
            this.cmbTimKiemTheo.TabIndex = 1;
            this.cmbTimKiemTheo.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tìm kiếm theo";
            // 
            // dtNgaySinh
            // 
            this.dtNgaySinh.Location = new System.Drawing.Point(131, 211);
            this.dtNgaySinh.Name = "dtNgaySinh";
            this.dtNgaySinh.Size = new System.Drawing.Size(194, 20);
            this.dtNgaySinh.TabIndex = 40;
            this.dtNgaySinh.TabStop = false;
            this.dtNgaySinh.Text = "Sunday, April 22, 2018";
            this.dtNgaySinh.Value = new System.DateTime(2018, 4, 22, 22, 55, 49, 186);
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column8.HeaderText = "STT";
            this.Column8.Name = "Column8";
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "Mã thẻ";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "Mã độc giả";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "Họ tên";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.HeaderText = "Ngày sinh";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column5.HeaderText = "Ngày làm thẻ";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column6.HeaderText = "Hạn thẻ";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column7.HeaderText = "Loại thẻ";
            this.Column7.Name = "Column7";
            // 
            // frm_PhieuDocGia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.radGroupBox2);
            this.Controls.Add(this.radGroupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frm_PhieuDocGia";
            this.Size = new System.Drawing.Size(1124, 560);
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox1)).EndInit();
            this.radGroupBox1.ResumeLayout(false);
            this.radGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtNgayLamThe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dthanThe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLoaiThe.EditorControl.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLoaiThe.EditorControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLoaiThe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHoTen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaDocGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaThe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).EndInit();
            this.radGroupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnCapNhap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnXoa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnThem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnLuu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).EndInit();
            this.radGroupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox4)).EndInit();
            this.radGroupBox4.ResumeLayout(false);
            this.radGroupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTuCanTim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo.EditorControl.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo.EditorControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTimKiemTheo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtNgaySinh)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadGroupBox radGroupBox1;
        private Telerik.WinControls.UI.RadLabel radLabel7;
        private Telerik.WinControls.UI.RadMultiColumnComboBox cmbLoaiThe;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadTextBox txtHoTen;
        private Telerik.WinControls.UI.RadTextBoxControl txtMaDocGia;
        private Telerik.WinControls.UI.RadTextBox txtMaThe;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox2;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox4;
        private Telerik.WinControls.UI.RadTextBox txtTuCanTim;
        private System.Windows.Forms.Label label2;
        private Telerik.WinControls.UI.RadMultiColumnComboBox cmbTimKiemTheo;
        private System.Windows.Forms.Label label1;
        private Telerik.WinControls.UI.RadButton btnCapNhap;
        private Telerik.WinControls.UI.RadButton btnXoa;
        private Telerik.WinControls.UI.RadButton btnThem;
        private Telerik.WinControls.UI.RadButton btnLuu;
        private Telerik.WinControls.UI.RadButton cmbTimKiem;
        private Telerik.WinControls.UI.RadDateTimePicker dtNgayLamThe;
        private Telerik.WinControls.UI.RadDateTimePicker dthanThe;
        private Telerik.WinControls.UI.RadDateTimePicker dtNgaySinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
    }
}
