﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoAnNMCNPM_QuanLyThuVien.DTO;
namespace DoAnNMCNPM_QuanLyThuVien.BUS
{
    public class ThuThu_BUS
    {



        bool KiemTra(ThuThu_DTO a)
        {
            return true;
        } 
        void Them(ThuThu_DTO z)
        {
            

       } 
    }
}
