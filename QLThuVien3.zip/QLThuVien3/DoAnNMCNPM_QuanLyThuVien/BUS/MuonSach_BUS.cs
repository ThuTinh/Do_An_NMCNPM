﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoAnNMCNPM_QuanLyThuVien.DTO;
using DoAnNMCNPM_QuanLyThuVien.DAL;
using System.Windows.Forms;
using System.Data;



namespace DoAnNMCNPM_QuanLyThuVien.BUS
{
  public  class MuonSach_BUS
  {
        
        MuonSach_DAL MS;
        public MuonSach_BUS()
        {
            MS = new MuonSach_DAL();
        }
      
        bool KiemTra(MuonSach_DTO muonSach)
        {
            if (muonSach.HoTen==""||muonSach.MaPhieuMuon==""||muonSach.MaThe == "" ||muonSach.MaThuThu == "" ||muonSach.NgayDuKienTra == "" ||muonSach.NgayMuon == "" ||muonSach.SoLuong==0)
                return false;
            return true;
        }
        public void Muon(MuonSach_DTO muonSach)
        {

            if (KiemTra(muonSach) == false)
                MessageBox.Show("Thông tin cung cấp chưa đầy đủ:");// + muonSach.HoTen + muonSach.MaPhieuMuon + muonSach.MaThe + muonSach.MaThuThu + muonSach.NgayDuKienTra + muonSach.NgayMuon + muonSach.SoLuong);
            else
            {
                if (MS.Luu(muonSach) == true)
                {
                    MessageBox.Show("Mượn Sách thành công!");
                }
                else
                    MessageBox.Show("Mượn Sách không thành công!");

            }

        }
        public void Luu(MuonSach_DTO muonsach )
        {
            MS.Luu(muonsach);
        }
        public DataTable Select()
        {
            return MS.Select();
        }
        public DataTable TimKiem(string TimKiemTheo, string tuCanTim)
        {
            return MS.TimKiem(TimKiemTheo, tuCanTim);
        }
        public DataTable TimTenBUS(MuonSach_DTO muonsach)
        {
            return MS.TimTen(muonsach);
        }
        public DataTable SoLuongSachMuonTuTruoc(string mathe)
        {
            return MS.SoLuongSachMuonTuTruoc(mathe);
        }
        public DataTable HanThe(MuonSach_DTO muonsach )
        {
            return MS.HanThe(muonsach);
        }
        public DataTable demsachquahantra(MuonSach_DTO muonsach)
        {
            return MS.demsachquahantra(muonsach);
        }
        public void update(string s,string y)
        {
            MS.update(s,y);
        }

       
  }
}

