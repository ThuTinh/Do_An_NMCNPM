﻿using DoAnNMCNPM_QuanLyThuVien.DAL;
using DoAnNMCNPM_QuanLyThuVien.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnNMCNPM_QuanLyThuVien.BUS
{
    public class ChiTietMuonSach_BUS
    {

        ChiTietMuonSach_DAL CTMS;
        public ChiTietMuonSach_BUS()
        {
            CTMS = new ChiTietMuonSach_DAL();
        }
        public void Luu(ChiTietMuonSach_DTO CTmuonsach)
        {
            if (CTMS.Luu(CTmuonsach))
            {
                MessageBox.Show("Lưu chi tiết mượn thành công");
            }
            else
            {
                MessageBox.Show("lưu chi tiết mượn thất bại");
            }
            CTMS.Luu(CTmuonsach);
           
        }
    }
}
