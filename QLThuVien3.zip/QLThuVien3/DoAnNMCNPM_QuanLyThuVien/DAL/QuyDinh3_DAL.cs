﻿using DoAnNMCNPM_QuanLyThuVien.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAnNMCNPM_QuanLyThuVien.DAL
{
   public class QuyDinh3_DAL
    {
       
      
    }
}
