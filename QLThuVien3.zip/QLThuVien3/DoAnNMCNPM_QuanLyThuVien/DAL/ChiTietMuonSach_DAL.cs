﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using DoAnNMCNPM_QuanLyThuVien.DTO;
using System.Data;
//using System.Windows.Forms;

namespace DoAnNMCNPM_QuanLyThuVien.DAL
{
    class ChiTietMuonSach_DAL
    {
        public ChiTietMuonSach_DAL()
        {
            Connect();
        }


        SqlConnection con;
        void Connect()
        {
            con = new SqlConnection("Data Source=.;Initial Catalog=QLTV;Integrated Security=True");
        }
        public bool Luu(ChiTietMuonSach_DTO ctmuonsach)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                string sqlQuery;
                if (ctmuonsach.ChuThich=="")
                {

                  
                   sqlQuery = @"insert into CHITIETMUON values ('" + ctmuonsach.MaPhieuMuon + "', '" + ctmuonsach.MaSach + "', " + "null" + ")";
                }
                else
                {
                    sqlQuery = @"insert into CHITIETMUON values ('" + ctmuonsach.MaPhieuMuon + "', '" + ctmuonsach.MaSach + "','" + ctmuonsach.ChuThich + "')";
                }
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();

                con.Close();
                return true; // muon thanh cong

            }
            catch //(Exception e)
            {
               // MessageBox.Show("chitietmuonsach_DAL.luu"+e.ToString());
                return false; // muon that bai;
            }
        }


    }
}
