﻿create  database QLTVtin
go
use QLTVtin
go

--drop database QLTVtin

create table TIEN
(
	GiaTien int check(GiaTien=1000)
)
insert into TIEN values (1000)


create table DOCGIA
(
	MaDocGia char(6) PRIMARY KEY,
	TenDocGia nvarchar(40) not null,
	GioiTinh nvarchar(4),
	NgaySinh smalldatetime,
	DiaChi nvarchar(50),
	Email varchar(50) unique
)

--select *from docgia
GO
insert into DOCGIA values ('DG001',N'Nguyễn Văn A','Nam','01/12/1997',N'731, Trần Hưng Đạo, Q 5, Tp HCM','nguyenvana@gmail.com')
insert into DOCGIA values ('DG002',N'Trần Ngọc Hân',N'Nữ','03/15/1998',N'23/5, Nguyễn Trãi, Q 5, Tp HCM','TranNgocHan98@gmail.com')
insert into DOCGIA values ('DG003',N'Trần Ngọc Linh',N'Nữ','12/02/1998',N'45, Nguyễn Cảnh Chân, Q 1, Tp HCM', 'ngoclinh0212@gmail.com')
insert into DOCGIA values ('DG004',N'Trần Minh Long','Nam','09/12/1998',N'50/34 Lê Đại Hành, Q 10, Tp HCM','tranminhlong@gmail.com')
insert into DOCGIA values ('DG005',N'Lê Nhật Minh','Nam','06/04/1999',N'34, Trương Định, Q 3, Tp HCM','MinhLe99@gmail.com')
insert into DOCGIA values ('DG006',N'Lê Hoài Thương',N'Nữ','08/05/1999',N'227, Nguyễn Văn Cừ, Q 5, Tp HCM','lehoaithuong@gmail.com')
insert into DOCGIA values ('DG007',N'Nguyễn Văn Tâm','Nam','09/23/1997',N'32/3, Trần Bình Trọng, Q 5, Tp HCM','nguyenvantam@gmail.com')
insert into DOCGIA values ('DG008',N'Phan Thị Thanh',N'Nữ','04/30/1997',N'45/2, An Dương Vương, Q 5, Tp HCM','thanh300497@gmail.com')
insert into DOCGIA values ('DG009',N'Lê Hà Vinh','Nam','08/19/1997',N'873, Lê Hồng Phong, Q 5, Tp HCM','lehavinh@gmail.com')
insert into DOCGIA values ('DG010',N'Hà Duy Lập','Nam','12/31/1999',N'34/34B, Nguyễn Trãi, Q 1, Tp HCM','haduylap@gmail.com')	
insert into DOCGIA values ('DG011',N'Lê Văn Tâm','Nam','09/30/1998',N'20/3 Đoàn Văn Bơ, Q 4, Tp HCM', 'levamtam@gmail.com')
insert into DOCGIA values ('DG012',N'Hà Đan Phụng', N'Nữ', '12/12/1997',N'30 Đặng Văn Bi, Q Thủ Đức, Tp HCM','Hadanphung@gmail.com')
insert into DOCGIA values ('DG013',N'Huyfnh Thị Thùy', N'Nữ', '12/03/1997', N'23/2 Lê Văn Việt, Q9, Tp HCM', ' HuynhThiThuy@gmail.com')
insert into DOCGIA values ('DG014', N'Phan Thị Mai', N'Nữ', '11/23/1997', N' 25 Lê Văn Việt, Q9, Tp HCM', 'PhanThiMai97@gmail.com')
insert into DOCGIA values ('DG015', N'Lê Thị Xuân Hoa', N'Nữ', '12/30/1996', N'30/05 Võ Văn Ngân, Q Thủ Đức, Tp HCM','Lethixuanhoa@gmai.com')


go
create table THEDOCGIA
(
	MaThe char(6) primary key,
	MaDocGia char(6) ,
	LoaiThe nvarchar(10),
	NgayLamThe smalldatetime,
	HanThe smalldatetime,
	constraint fk_THEDOCGIA_DOCGIA foreign key(MaDocGia) references DOCGIA(MaDocGia)
)
GO


insert into THEDOCGIA values ('MT0000', 'DG001','LTA', '06/30/2017','06/30/2018')
insert into THEDOCGIA values ('MT0001', 'DG002','LTA', '06/30/2017','06/30/2018')
insert into THEDOCGIA values ('MT0002', 'DG002', 'LTA', ' 06/30/2017', '06/30/2018')
insert into THEDOCGIA values ('MT0003', 'DG003', 'LTB', '07/15/2017', '07/15/2018')
insert into THEDOCGIA values ('MT0004', 'DG004', 'LTA', '07/23/2017', '07/23/2018')
insert into THEDOCGIA values ('MT0005', 'DG005', 'LTB', '07/29/2017', '07/29/2018')
insert into THEDOCGIA values ('MT0006', 'DG006', 'LTB', '09/13/2017', '09/13/2018')
insert into THEDOCGIA values ('MT0007', 'DG007', 'LTB', '10/23/2017', '10/23/2018')
insert into THEDOCGIA values ('MT0008', 'DG008', 'LTA', '10/23/2017', '10/23/2018')
insert into THEDOCGIA values ('MT0009', 'DG009', 'LTA', '10/23/2017', '10/23/2018')
insert into THEDOCGIA values ('MT0010', 'DG010', 'LTA', '12/03/2017', '12/03/2018')
insert into THEDOCGIA values ('MT0011', 'DG011', 'LTB', '12/04/2017', '12/04/2018')
insert into THEDOCGIA values ('MT0012', 'DG012', 'LTB', '01/20/2018', '01/20/2019')
insert into THEDOCGIA values ('MT0013', 'DG013', 'LTA', '01/20/2018', '01/20/2019')
insert into THEDOCGIA values ('MT0014', 'DG014', 'LTA', '03/04/2018', '03/04/2019')
insert into THEDOCGIA values ('MT0015', 'DG015', 'LTA', '04/04/2018', '04/04/2018')



go
create table THUTHU
(
	MaThuThu char(6) primary key,
	TenThuThu nvarchar(40),
	GioiTinh nvarchar(4),
	NgaySinh smalldatetime,
	DiaChi nvarchar(50), 
	Email varchar(50) unique,
	ChucVu nvarchar(20)
)

GO
insert into THUTHU values ('TT0001', N'Lê Thị Hồng Hoa', N'Nữ', N'02/19/1984', '20/3 Lê Văn Việt, Q9, TpHCM', 'lethihonghoa@gmail.com', 'TT') 
insert into THUTHU values ('TT0002', N'Trần Thị Thùy', N'Nũ', N'12/09/1992', '15 Tăng Nhơn Phú, Q9, Tp HCM', 'TranThiThuy@gmail.com', 'TT')
insert into THUTHU values ('TT0003', N'Nguyễn Văn Nam', 'Nam', N'03/13/1989', '30/2 Đặng Văn Bi, Q Thủ Đức, Tp HCM', 'vannam0312@gmail.com','TT') 



go
create table PHIEUMUON
(
	MaPhieuMuon char(6) primary key,
	MaThuThu char(6),
	MaThe char(6),

	NgayMuon smalldatetime,
	NgayDuKienTra smalldatetime,
	SoLuong int
	constraint fk_PHIEUMUON_THUTHU foreign key(MaThuThu) references THUTHU(MaThuThu),
	constraint fk_PHIEUMUON_THEDOCGIA foreign key(MaThe) references THEDOCGIA(MaThe),
	
)

GO
insert into PHIEUMUON values ('PM0001', 'TT0002', 'MT0001', '07/05/2017','08/04/2017',2)
insert into PHIEUMUON values ('PM0002', 'TT0001', 'MT0002', '07/15/2017','08/14/2017',1)
insert into PHIEUMUON values ('PM0003', 'TT0002', 'MT0005', '08/30/2017','09/30/2017',3)
insert into PHIEUMUON values ('PM0004', 'TT0001', 'MT0001', '08/30/2017','09/29/2017',2)
insert into PHIEUMUON values ('PM0005', 'TT0002', 'MT0007', '11/15/2017','12/15/2017',5)
insert into PHIEUMUON values ('PM0006', 'TT0002', 'MT0005', '11/15/2017','12/15/2017',5)
insert into PHIEUMUON values ('PM0007', 'TT0002', 'MT0008', '12/30/2017','1/29/2018',3)
insert into PHIEUMUON values ('PM0008', 'TT0001', 'MT0010', '01/25/2018','02/24/2018',3)
insert into PHIEUMUON values ('PM0009', 'TT0001', 'MT0008', '01/25/2018','02/24/2018',1)
insert into PHIEUMUON values ('PM0010', 'TT0003', 'MT0005', '01/25/2018','02/24/2018',3)
insert into PHIEUMUON values ('PM0011', 'TT0003', 'MT0011', '01/27/2018','02/26/2018',4)
insert into PHIEUMUON values ('PM0012', 'TT0001', 'MT0003', '01/28/2018','02/27/2018',4)
insert into PHIEUMUON values ('PM0013', 'TT0003', 'MT0001', '01/28/2018','02/27/2018',3)
insert into PHIEUMUON values ('PM0014', 'TT0003', 'MT0014', '04/20/2018','05/20/2018',2)
insert into PHIEUMUON values ('PM0015', 'TT0002', 'MT0015', '04/25/2018','05/25/2018',3)



go
create table THELOAISACH
(
	TenTheLoai nvarchar(40) primary key,
)

insert into THELOAISACH values (N'Giáo trình')
insert into THELOAISACH values (N'Tham khảo')
insert into THELOAISACH values (N'Luận văn')


go
create table DAUSACH
(
	MaDauSach char(6) primary key,
	TenDauSach nvarchar(80),
	TacGia nvarchar(40),
	TenTheLoai nvarchar(40),
	NamSanXuat int,
	NhaSanXuat nvarchar(50),
	Gia money,
	SoLuong int,
	constraint fk_SACH_THELOAI foreign key(TenTheLoai) references THELOAISACH(TenTheLoai),
)
GO



insert into DAUSACH values ('GT1', N'Thiết kế cơ sở dữ liệu',N'Trịnh Minh Tuấn', N'Giáo trình', 2017, N'Nxb.Đại học quốc gia TPHCM', 57000, 100)
insert into DAUSACH values ('GT2', N'Xử lý ngôn ngữ tự nhiên',N'Nguyễn Tuấn Đăng', N'Giáo trình', 2012, N'Nxb.Đại học quốc gia TPHCM', 45000, 100)
insert into DAUSACH values ('GT3', N'Pháp chứng kỹ thuật số',N'Đàm Quang Hồng Hải', N'Giáo trình', 2016, N'Nxb.Đại học quốc gia TPHCM', 64000, 100)
insert into DAUSACH values ('GT4', N'Hệ thống nhúng',N'Vũ Đức Lung, Trần Ngọc Đức', N'Giáo trình', 2016, N'Nxb.Đại học quốc gia TPHCM', 55000, 100)
insert into DAUSACH values ('GT5', N'Thiết kế vi mạch số',N'Nguyễn Minh Sơn, Nguyễn Trần Sơn', N'Giáo trình', 2016, N'Nxb.Đại học quốc gia TPHCM', 39000, 100)
insert into DAUSACH values ('TK1', N'Tại sao Mác đúng',N'Terry Eagleton', N'Tham khảo', 2014, N'Nxb.Chính trị - Hành chính', 57000, 100)
insert into DAUSACH values ('TK2', N'Hồ Chí Minh : Nhà tư tưởng lỗi lạc',N'Song Thanh', N'Tham khảo', 2013, N'Nxb.Đại học quốc gia TPHCM', 57000, 100)
insert into DAUSACH values ('TK3', N'Bàn về tinh thần pháp luật : De Lesprit deslois',N'Montesquieu', N'Tham khảo', 2013, N'Nxb.Đại học quốc gia TPHCM', 57000, 100)
insert into DAUSACH values ('TK4', N'Chúng ta kế thừa di sản nào? ',N'Văn Tạo', N'Tham khảo', 2013, N'Nxb.Đại học quốc gia TPHCM', 57000, 100)
insert into DAUSACH values ('TK5', N'Phương pháp và phong cách Hồ Chí Minh ',N'Đặng Xuân Kỵ', N'Tham khảo', 2013, N'Nxb.Đại học quốc gia TPHCM', 57000, 100)
insert into DAUSACH values ('LV1', N'Kỹ thuật kiểm thử đột biến',N'Hoàng Thị Thanh Thủy', N'Giáo trình', 2012, null, null, null)
insert into DAUSACH values ('LV2', N'Ẩn dữ liệu ảnh 3D',N'Nguyễn Bảo Bình', N'Giáo trình', 2012, null, null, null)
insert into DAUSACH values ('LV3', N'Tìm kiếm tự động văn bản song ngữ Anh - Việt từ internet',N'Ngô Quốc Hùng', N'Giáo trình', 2013, null, null, null)
insert into DAUSACH values ('LV4', N'Nghiên cứu cải tiến thuật toán phân lớp sử dụng cây quyết định đệ quy',N'Nguyễn Minh Luân', N'Giáo trình',2012, null, null, null)
insert into DAUSACH values ('LV5', N'Hệ thống quản lý tiền lương trên mạng Wan tại bưu điện tỉnh Sóc Trăng',N'Nguyễn Trí Nghĩa', N'Giáo trình', 2013, null, null, null)



go
create table CUONSACH
(
	MaSach char(6) primary key,
	MaDauSach char(6),
	TinhTrang char(2) check(TinhTrang='N'or TinhTrang='Y'),
	NgayNhap smalldatetime,
	ChuThich text,
	constraint fk_SACH_DAUSACH foreign key(MaDauSach) references DAUSACH(MaDauSach)
)
GO
insert into CUONSACH values ('GT1001', 'GT1', 'N', '12/5/2017', null)
insert into CUONSACH values ('GT1002', 'GT1', 'N', '12/5/2017', null)
insert into CUONSACH values ('GT2001', 'GT2', 'N', '12/5/2012', null)
insert into CUONSACH values ('GT3001', 'GT3', 'N', '12/5/2016', null)
insert into CUONSACH values ('GT3002', 'GT3', 'N', '12/5/2016', null)
insert into CUONSACH values ('TK1001', 'TK1', 'N', '03/14/2014', null)
insert into CUONSACH values ('TK1002', 'TK1', 'N', '03/14/2014', null)
insert into CUONSACH values ('TK1003', 'TK1', 'N', '03/14/2014', null)
insert into CUONSACH values ('TK1004', 'TK1', 'N', '03/14/2014', null)
insert into CUONSACH values ('TK5001', 'TK5', 'N', '07/29/2013', null)
insert into CUONSACH values ('LV1001', 'LV1', 'N', '12/28/2012', null)
insert into CUONSACH values ('LV4001', 'LV4', 'N', '10/23/2012', null)
insert into CUONSACH values ('LV4002', 'LV4', 'N', '10/23/2012', null)
insert into CUONSACH values ('LV4003', 'LV4', 'N', '10/23/2012', null)
insert into CUONSACH values ('LV4004', 'LV4', 'N', '10/23/2012', null)
insert into CUONSACH values ('LV4005', 'LV4', 'N', '10/23/2012', null)

go
create table CHITIETMUON
(
	MaPhieuMuon char(6) not null unique,
	MaSach char(6) not null unique,
	ChuThich ntext ,
	constraint pk_CHITIETMUON primary key( MaPhieuMuon,MaSach),
	constraint fk_CHITIETMUON_SACH foreign key(MaSach) references CUONSACH(MaSach),
)
GO
insert into CHITIETMUON values ('PM0001', 'GT1001', null)
insert into CHITIETMUON values ('PM0002', 'GT1002', null)
insert into CHITIETMUON values ('PM0003', 'GT2001', null)
insert into CHITIETMUON values ('PM0004', 'GT3001', null)
insert into CHITIETMUON values ('PM0005', 'GT3002', null)
insert into CHITIETMUON values ('PM0006', 'TK1001', null)
insert into CHITIETMUON values ('PM0007', 'TK1002', null)
insert into CHITIETMUON values ('PM0008', 'TK1003', null)
insert into CHITIETMUON values ('PM0009', 'TK1004', null)
insert into CHITIETMUON values ('PM0010', 'TK5001', null)
insert into CHITIETMUON values ('PM0011', 'LV1001', null)
insert into CHITIETMUON values ('PM0012', 'LV4001', null)
insert into CHITIETMUON values ('PM0013', 'LV4003', null)
insert into CHITIETMUON values ('PM0014', 'LV4004', null)
insert into CHITIETMUON values ('PM0015', 'LV4005', null)



go
create table PHIEUTRA
(
	MaPhieuTra char(6) primary key,
	MaThe char(6) not null,
	MaThuThu char(6) not null,
	NgayTra smalldatetime,
	soluong int ,
	
	constraint fk_PHIEUTRA_THUTHU foreign key(MaThuThu) references THUTHU(MaThuThu),
	constraint fk_PHIEUTRA_THEDOCGIA foreign key(MaThe) references THEDOCGIA(MaThe),
)
GO
insert into PHIEUTRA values ( 'PT0001', 'MT0001', 'TT0002', '07/20/2017', 2)
insert into PHIEUTRA values ( 'PT0002', 'MT0002', 'TT0001', '07/30/2017', 1)
insert into PHIEUTRA values ( 'PT0003', 'MT0005', 'TT0002', '09/05/2017', 3)
insert into PHIEUTRA values ( 'PT0004', 'MT0001', 'TT0001', '09/30/2017', 2)
insert into PHIEUTRA values ( 'PT0005', 'MT0007', 'TT0002', '12/10/2017', 5)
insert into PHIEUTRA values ( 'PT0006', 'MT0005', 'TT0002', '12/14/2017', 5)
insert into PHIEUTRA values ( 'PT0007', 'MT0008', 'TT0002', '01/19/2018', 3)
insert into PHIEUTRA values ( 'PT0008', 'MT0010', 'TT0001', '02/12/2018', 3)
insert into PHIEUTRA values ( 'PT0009', 'MT0008', 'TT0001', '02/02/2018', 1)
insert into PHIEUTRA values ( 'PT0010', 'MT0005', 'TT0003', '02/16/2018', 3)
insert into PHIEUTRA values ( 'PT0011', 'MT0011', 'TT0003', '02/18/2018', 4)
insert into PHIEUTRA values ( 'PT0012', 'MT0003', 'TT0001', '02/28/2018', 4)
insert into PHIEUTRA values ( 'PT0013', 'MT0001', 'TT0003', '02/23/2018', 3)
insert into PHIEUTRA values ( 'PT0014', 'MT0014', 'TT0003', '05/15/2018', 2)
insert into PHIEUTRA values ( 'PT0015', 'MT0015', 'TT0002', '05/25/2018', 3)






go
create table CHITIETTRA
(
	MaPhieuTra char(6) not null ,
	MaPhieuMuon char(6) not null,
	MaSach char(6) not null ,
	SoNgayTraMuon int,
	ChuThich ntext,
	constraint pk_CHITIETTRA primary key (MaPhieuTra,MaSach),
	constraint fk_CHITIETTRA_PHIEUMUON foreign key(MaPhieuMuon) references PHIEUMUON(MaPhieuMuon),
	constraint fk_CHITIETTRA_PHIEUTRA foreign key (MaPhieuTra) references PHIEUTRA(MaPhieuTra),
	constraint fk_CHITIETTRA_CUONSACH foreign key (MaSach) references CUONSACH (MaSach)
)

GO
insert into CHITIETTRA values ('PT0001',  'PM0001','GT1001', 15 , null)
insert into CHITIETTRA values ('PT0002', 'PM0002','GT1002', 15 , null)
insert into CHITIETTRA values ('PT0003','PM0003', 'GT2001', 05, null)
insert into CHITIETTRA values ('PT0004', 'PM0004','GT3001', 30, null)
insert into CHITIETTRA values ('PT0005','PM0005', 'GT3002', 25, null)
insert into CHITIETTRA values ('PT0006','PM0006',  'TK1001', 29, null)
insert into CHITIETTRA values ('PT0007','PM0007',  'TK1002', 20, null)
insert into CHITIETTRA values ('PT0008','PM0008', 'TK1003', 28, null)
insert into CHITIETTRA values ('PT0009', 'PM0009','TK1004', 08, null)
insert into CHITIETTRA values ('PT0010', 'PM0010','TK5001', 20, null)
insert into CHITIETTRA values ('PT0011', 'PM0011','LV1001', 22, null)
insert into CHITIETTRA values ('PT0012', 'PM0012','LV4001', 31, N'Trễ hạn 1 ngày : 4 cuốn sách ')
insert into CHITIETTRA values ('PT0013','PM0013', 'LV4003', 26,  null)
insert into CHITIETTRA values ('PT0014', 'PM0014','LV4004', 25, null)
insert into CHITIETTRA values ('PT0001','PM0015', 'LV4005', 30, null)



go
create trigger INSERT_CHITIETTRA_SoNgayTraMuon
on CHITIETTRA
for INSERT
as	
	declare @MaSach char(6), @SoNgayTraMuon int,@MaPhieuTra char(6),@NgayTra smalldatetime, @MaPhieuMuon char(6),@NgayMuon smalldatetime -- khai bao bien
	select @MaPhieuTra=MaPhieuTra,@MaSach =MaSach,@MaPhieuMuon=MaPhieuMuon from inserted-- lay gia tri ra can dung select--B1
	select @NgayTra=NgayTra from PHIEUTRA WHERE MaPhieuTra=@MaPhieuTra
	select @NgayMuon=NgayMuon from PHIEUMUON WHERE MaPhieuMuon=@MaPhieuMuon
	UPDATE CHITIETTRA
	SET SoNgayTraMuon= DATEDIFF (day, @NgayMuon, @NgayTra)
	WHERE MaPhieuTra=@MaPhieuTra and MaSach =@MaSach


create table QUYDINH1
(
	TuoiMin int,
	TuoiMax int,
	HanThe smalldatetime
)

create table QUYDINH2
(
	SoTheLoai int,
	HanTHoiGianNhanSach Smalldatetime
)


create table QUYDINH3
(
	SoSachMuonToiDa int,
	ThoiGianMuonToiDa int
)


go
create table PHIEUTIENPHAT
(
	MaPhieuPhat char(6) primary key,
	MaPhieuTra char(6),
	TongNo int ,
	constraint fk_PHIEUTIENPHAT_PHIEUTRA foreign key (MaPhieuTra) references PHIEUTRA (MaPhieuTra)
)
go
create trigger INSERT_PHIEUTIENPHAT_TongNo1
on PHIEUTIENPHAT
for INSERT
as	
	declare @GiaTien int,@MaPhieuPhat char(6),@SoNgayTraMuon int,@MaPhieuTra char(6)
	select @MaPhieuphat=MaPhieuPhat, @MaPhieuTra=MaPhieuTra from inserted-- lay gia tri ra can dung select--B1
	select @GiaTien=GiaTien from TIEN
	select @SoNgayTraMuon=SoNgayTraMuon from CHITIETTRA WHERE MaPhieuTra=@MaPhieuTra
	UPDATE PhieuTienPhat
	SET TongNo= @GiaTien*@SoNgayTraMuon
	WHERE MaPhieuPhat=@MaPhieuPhat

	
